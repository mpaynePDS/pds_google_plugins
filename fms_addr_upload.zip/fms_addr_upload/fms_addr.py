# -*- coding: utf-8 -*-
"""
Created on Friday, Jan 24, 2025
@author: Marie Payne
"""
import sys
import warnings
import os
import openpyxl
import pandas as pd
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import *
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo
#settings
warnings.filterwarnings('ignore')
def a(output, progressBar, zones):
    project = QgsProject.instance()
    progressBar.setValue(0)
    addr = project.mapLayersByName('address')[0]
    proj = project.mapLayersByName('project')[0]
    # Filter data to project boundary area
    print(str(zones[0]))
    processing.run("qgis:selectbyattribute", {'INPUT':proj,'FIELD':'name','OPERATOR':0,'VALUE':f'{zones[0]}','METHOD':0})
    print(f'Total Projects Selected {proj.selectedFeatureCount()}')
    #processing.run("qgis:selectbyattribute", {'INPUT':proj,'FIELD':'name','OPERATOR':0,'VALUE':f'{zones[0]}','METHOD':0})
    #filter_addr = processing.run("native:selectbylocation", {'INPUT':'postgres://dbname=\'google\' host=gis.precision-design.org port=51549 authcfg=pds1234 key=\'globalid\' estimatedmetadata=true srid=4326 type=Point checkPrimaryKeyUnicity=\'1\' table="hutto"."address" (geom)','PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition('dbname=\'google\' host=gis.precision-design.org port=51549 authcfg=pds1234 key=\'gobalid\' estimatedmetadata=true srid=4326 type=MultiPolygon checkPrimaryKeyUnicity=\'1\' table="hutto"."project" (geom)', selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})['OUTPUT']
    processing.run("native:selectbylocation", {'INPUT':addr,'PREDICATE':[6],'INTERSECT':QgsProcessingFeatureSourceDefinition(proj.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
    print(f'Total Addresses Selected {addr.selectedFeatureCount()}')
    #filter_addr = processing.run("native:selectbylocation", {'INPUT':addr,'PREDICATE':[0],'INTERSECT': QgsProcessingFeatureSourceDefinition('project', selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})['OUTPUT']
    # Template
    here = os.path.dirname(os.path.abspath(__file__))
    template = os.path.join(here, 'Address_Curation_Template__Rev11_20240827.xlsx')
    wb = openpyxl.load_workbook(template)
    ws_create = wb["Address Create.csv"]
    ws_delete = wb["Address Delete.csv"]
    ws_modify = wb['Address Modify.csv']
    ws_discrepancies = wb['Address Discrepancies']
    ws_hhp = wb['HHP Summary']
    # Data
    create = {}
    delete = []
    modify = {}
    discrepancies = {}
    atype = {'SFU':0, 'MDU':0,
             'SBU':0, 'MTU':0,'LCU':0,'VACANT':0}
    fdec_type = {'SFU':0, 'MDU':0, 'SBU':0, 'MTU':0}
    planned, dnb, fdec, ab = 0,0,0,0
    total = addr.featureCount()
    print(f'Total Addresses Selected {addr.selectedFeatureCount()}')
    count = 0
    for f in addr.getSelectedFeatures():
        progressBar.setValue(int((count/total)*100)-5)
        if f['pds_delete_feature'] in [None, ''] or f['pds_delete_feature'] != 'DEL':
            #address type count
            atype[f['pds_addresstype'].split('_')[-1]] += 1
            #address status count
            if f['status'] == 'PL':
                planned += 1
            elif f['status'] == 'DNB':
                dnb += 1
            elif ['status'] == 'AB':
                ab += 1
            elif f['status'] == 'FDEC':
                fdec+= 1    
                # FDEC count
                if f['pds_addresstype'] == 'SFU':
                    fdec_type['SFU'] += 1
                if f['pds_addresstype'] == 'MDU':
                    fdec_type['MDU'] +=1
                if f['pds_addresstype'] == 'SBU':
                    fdec_type['SBU'] +=1
                if f['pds_addresstype'] == 'SFU':
                    fdec_type['MTU'] +=1
            #address fields comparsison
            pairs = [[f['pds_streetaddress'], f['streetaddress']],
                    [f['pds_unitnumber'], f['unitnumber']],
                    [f['pds_city'], f['city']],
                    [f['pds_county'], f['county']],
                    [f['pds_state'], f['state']],
                    [f['pds_zipcode'], f['zipcode']],                
                    [f['pds_latitude'], f['latitude']],
                    [f['pds_longitude'], f['longitude']],
                    [f['pds_addresstype'], f['addresstype']],
                    [f['pds_addresssubtype'], f['addresssubtype']]
            ]
        if f['gfid'] is None or f['gfid'] == '' or not f['gfid']:
            create[f['globalid']]=[f['pds_streetaddress'],
                f['pds_unitnumber'] if f['pds_unitnumber'] else '',
                f['pds_city'] if f['pds_city'] else '',
                f['pds_county'] if f['pds_county'] else '',
                f['pds_state'] if f['pds_state'] else '',
                f['pds_zipcode'] if f['pds_zipcode'] else '',
                f['pds_latitude'] if f['pds_latitude'] else '',
                f['pds_longitude'] if f['pds_longitude'] else '',
                f['pds_addresstype'] if f['pds_addresstype'] else '',
                f['pds_addresssubtype'] if f['pds_addresssubtype'] else '']
            discrepancies[f['globalid']] = [None, f['pds_streetaddress'], 'Address create', '1', 'ACA Create' , 'Residential' if any( x in f['pds_addresstype'] for x in ['SFU', 'MDU']) else 'Commercial' if any( x in f['pds_addresstype'] for x in ['SBU', 'MTU', 'LCU']) else None]

        elif f['pds_delete_feature'] == 'DEL':
            delete.append([f['gfid'], f['pds_delete_reason']])
            if f['pds_addresstype'] not in [None, '']:
                discrepancies[f['gfid']]= [f['streetaddress'] if f['streetaddress'] not in [None, ''] else None, f['pds_streetaddress'] if f['pds_streetaddress'] not in [None, ''] else None, 'Address delete', '1', 'ACA Delete' , 'Residential' if any( x in f['pds_addresstype'] for x in ['SFU', 'MDU']) else 'Commercial' if any( x in f['pds_addresstype'] for x in ['SBU', 'MTU', 'LCU']) else None]
            else:
                discrepancies[f['gfid']]= [f['streetaddress'] if f['streetaddress'] not in [None, ''] else None, f['pds_streetaddress'] if f['pds_streetaddress'] not in [None, ''] else None, 'Address delete', '1', 'ACA Delete' ,  None]
        elif any(l[0]!=l[1] for l in pairs):
            modify[f['gfid']]=[l[0] for l in pairs]
            
            analysis = ''
            if pairs[0][0] != pairs[0][1]:
                analysis += f"change streetaddress from {f['streetaddress']} to {f['pds_streetaddress']};"
            if pairs[1][0] != pairs[1][1]:
                analysis += f"change unitnumber from {f['unitnumber']} to {f['pds_unitnumber']};"
            if pairs[2][0] != pairs[2][1]:
                analysis += f"change city from {f['city']} to {f['pds_city']};"
            if pairs[3][0] != pairs[3][1]:
                analysis += f"change county from {f['county']} to {f['pds_county']};"
            if pairs[4][0] != pairs[4][1]:
                analysis += f"change state from {f['state']} to {f['pds_state']};"
            if pairs[5][0] != pairs[5][1]:
                analysis += f"change zipcode from {f['zipcode']} to {f['pds_zipcode']};"
            if pairs[8][0] != pairs[8][1]:
                analysis += f"change addresstype from {f['addresstype']} to {f['pds_addresstype']};"
            if pairs[9][0] != pairs[9][1]:
                analysis += f"change addresssubtype from {f['addresssubtype']} to {f['pds_addresssubtype']};"
            if f['pds_latitude'] == f['latitude'] and f['pds_longitude']== f['longitude']:
                solution = 'Modify in FMS'
            else:
                solution = 'Modify in FMS and ACA Modify'
                analysis+= 'update lat and long'
            discrepancies[f['gfid']] = [f['streetaddress'], f['pds_streetaddress'], analysis, '1', solution, 'Residential' if any( x in f['pds_addresstype'] for x in ['SFU', 'MDU']) else 'Commercial' if any( x in f['pds_addresstype'] for x in ['SBU', 'MTU', 'LCU']) else None]
    
    
    # HHP Summary Worksheet
    ws_hhp['B5'] = atype['SFU']
    #ws_hhp['B6'] = atype['DUPLEX']
    #ws_hhp['B7'] = atype['TRIPLEX']
    #ws_hhp['B8'] = atype['QUADRUPLEX']
    ws_hhp['B9'] = atype['MDU']#['APARTMENT']
    ws_hhp['B10'] = atype['SBU']
    ws_hhp['B11'] = atype['MTU']
    ws_hhp['B12'] = atype['LCU']
    ws_hhp['B13'] = atype['VACANT']
    ws_hhp['B14'] = fdec
    ws_hhp['B15'] = planned
    ws_hhp['B16'] = dnb
    # FDEC
    ws_hhp['B31']=fdec_type['SFU']
    ws_hhp['B32']=fdec_type['MDU']
    ws_hhp['B33']=fdec_type['SBU']
    ws_hhp['B34']=fdec_type['MTU']
    progressBar.setValue(96)
    # Create Worksheet
    r = 3
    for key in create:
        ws_create.cell(row = r, column=1).value = create[key][0]#streetaddress
        try:
            ws_create.cell(row = r, column=2).value = create[key][1]#unit
        except:
            print(f'{key}: unit - {create[key][1]}')
        ws_create.cell(row = r, column=3).value = create[key][2]#city
        ws_create.cell(row = r, column=4).value = create[key][3]#county
        ws_create.cell(row = r, column=5).value = create[key][4]#state
        ws_create.cell(row = r, column=6).value = create[key][5]# zip, skip col 7
        ws_create.cell(row = r, column=8).value = create[key][6]#lat
        ws_create.cell(row = r, column=9).value = create[key][7]#long
        ws_create.cell(row = r, column=10).value = create[key][8]#addresstype
        ws_create.cell(row = r, column=11).value = create[key][9]#addresssubtype
        r += 1
    progressBar.setValue(97)
    # Delete Worksheet
    r = 3
    for key in delete:
        ws_delete.cell(row=r, column =1).value = key[0]
        ws_delete.cell(row=r, column= 4).value= key[1] if key[1] else "N/A"
        r+=1
    # Modify worksheet
    r = 3
    for key in modify:
        ws_modify.cell(row = r, column=1).value = key
        ws_modify.cell(row = r, column=2).value = modify[key][0]#streetaddress
        ws_modify.cell(row = r, column=3).value = modify[key][1] if modify[key][1] not in [None, 'nan'] else ''#unit
        ws_modify.cell(row = r, column=4).value = modify[key][2] if modify[key][2] not in [None, 'nan'] else ''#city
        ws_modify.cell(row = r, column=5).value = modify[key][3] if modify[key][3] not in [None, 'nan'] else ''#county
        ws_modify.cell(row = r, column=6).value = modify[key][4] if modify[key][4] not in [None, 'nan'] else ''#state
        ws_modify.cell(row = r, column=7).value = modify[key][5].split('-')[0] if '-' in modify[key][5] else modify[key][5]#zip
        ws_modify.cell(row = r, column=8).value = modify[key][5].split('-')[-1] if '-' in modify[key][5] else modify[key][5]#+4
        ws_modify.cell(row = r, column=9).value = modify[key][6]#lat
        ws_modify.cell(row = r, column=10).value = modify[key][7]#long
        ws_modify.cell(row = r, column=11).value = modify[key][8]#addresstype
        ws_modify.cell(row = r, column=12).value = modify[key][9]#subaddresstype
        r += 1
    progressBar.setValue(98)
    # Discrepancies worksheet
    r = 3
    for key in discrepancies:
        ws_discrepancies.cell(row = r, column=1).value = discrepancies[key][0]#streetaddress
        ws_discrepancies.cell(row = r, column=2).value = discrepancies[key][1]#pds_streetaddress
        ws_discrepancies.cell(row = r, column=3).value = discrepancies[key][2]#analysis
        ws_discrepancies.cell(row = r, column=4).value = discrepancies[key][3]#hhp
        ws_discrepancies.cell(row = r, column=5).value = discrepancies[key][4]#solution
        ws_discrepancies.cell(row = r, column=6).value = discrepancies[key][5]#type
        r += 1
    progressBar.setValue(99)
    wb.save(f'{output}\\FMS_Address_Curation_{zones[0]}.xlsx')
    progressBar.setValue(100)
    

        
    

        


