# -*- coding: utf-8 -*-
"""
Created on October 20, 2025
Google BOM
@author: Marie Payne
"""
import os
import sys
import math
from openpyxl import load_workbook
from datetime import datetime
from itertools import chain
from qgis.core import *
from qgis import processing

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __SAT__(workorderid, outputfolder, dbox, progressBar,errorFormat, warningFormat, validFormat):
    try:
        project = QgsProject.instance()
        if outputfolder in [None, '']:
            dbox.append(errorFormat.format('Select an Output Location to continue.'))
            return
        progressBar.setValue(1)
        #-------------------------------------------------------------------------------------
        # Set template
        #-------------------------------------------------------------------------------------
        here = os.path.dirname(os.path.abspath(__file__))
        template = os.path.join(here, 'Rake-Off_Master_Template_Rev_22.xlsx')
        wb = load_workbook(template)
        ws_template = wb["SAT"] 
        progressBar.setValue(3)
        #-------------------------------------------------------------------------------------
        # Reference Relevant Layers
        #-------------------------------------------------------------------------------------
        project_layer = project.mapLayersByName('project')[0]
        path_layer = project.mapLayersByName('path')[0]
        conduit_layer = project.mapLayersByName('conduit')[0]
        strand_layer = project.mapLayersByName('strand')[0]
        fibercable_layer = project.mapLayersByName('fibercable')[0]
        converse_roads_layer = project.mapLayersByName('converse_roads_2025')[0]
        spliceclosure_layer = project.mapLayersByName('spliceclosure')[0]
        structure_layer = project.mapLayersByName('structure')[0]
        equipment_layer = project.mapLayersByName('equipment')[0]
        riser_layer = project.mapLayersByName('riser')[0]
        slackloop_layer = project.mapLayersByName('slackloop')[0]
        pole_layer = project.mapLayersByName('pole')[0]
        permit_layer = project.mapLayersByName('permitarea')[0]
        grid_layer = project.mapLayersByName('grid')[0]
        progressBar.setValue(5)
        #-------------------------------------------------------------------------------------
        # Define the AOI
        #-------------------------------------------------------------------------------------
        processing.run("qgis:selectbyattribute", {'INPUT':project_layer, 'FIELD': 'workorderid', 'OPERATOR': 0, 'VALUE': workorderid, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        #-------------------------------------------------------------------------------------
        # Pre Clip Layers by Grid
        #-------------------------------------------------------------------------------------
        # Filter Grid to Workorderid
        grid = processing.run("native:extractbyexpression", {'INPUT':grid_layer, 'EXPRESSION': f'"workorderid" = \'{workorderid}\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        #sort grid inputs by grid_number
        for g in chain(grid.getFeatures(), [None]):
            if g is not None:
                grid_id = g['grid_number']
                temp_grid_layer = QgsVectorLayer("Polygon?crs={}".format(grid.crs().authid()), "temp_grid", "memory")
                temp_grid_layer.dataProvider().addFeatures([g])

                path_clip = processing.run("native:clip", {'INPUT':path_layer,'OVERLAY': temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                conduit_clip = processing.run("native:clip", {'INPUT':conduit_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                strand_clip = processing.run("native:clip", {'INPUT':strand_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                fibercable_clip = processing.run("native:clip", {'INPUT':fibercable_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                equipment_clip = processing.run("native:clip", {'INPUT':equipment_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                spliceclosure_clip = processing.run("native:clip", {'INPUT':spliceclosure_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                structure_clip = processing.run("native:clip", {'INPUT':structure_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                riser_clip = processing.run("native:clip", {'INPUT':riser_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                slackloop_clip = processing.run("native:clip", {'INPUT':slackloop_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                pole_clip = processing.run("native:clip", {'INPUT':pole_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                permit_clip = processing.run("native:clip", {'INPUT':permit_layer,'OVERLAY':temp_grid_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

            else:
                grid_id = workorderid
                path_clip = path_layer
                conduit_clip = conduit_layer
                strand_clip = strand_layer
                fibercable_clip = fibercable_layer
                equipment_clip = equipment_layer
                spliceclosure_clip = spliceclosure_layer
                structure_clip = structure_layer
                riser_clip = riser_layer
                slackloop_clip = slackloop_layer
                pole_clip = pole_layer
                permit_clip = permit_layer        

            #-------------------------------------------------------------------------------------
            # Create individual worksheet
            #-------------------------------------------------------------------------------------
            ws = wb.copy_worksheet(ws_template)
            ws.title = str(grid_id)
            dbox.append(f'--{str(grid_id)}--')
            #-------------------------------------------------------------------------------------
            # Pre Filter layers by Workorderid and FDA
            #-------------------------------------------------------------------------------------
            path = processing.run("native:extractbyexpression", {'INPUT':path_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit = processing.run("native:extractbyexpression", {'INPUT':conduit_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            strand = processing.run("native:extractbyexpression", {'INPUT':strand_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fibercable = processing.run("native:extractbyexpression", {'INPUT':fibercable_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            equipment = processing.run("native:extractbyexpression", {'INPUT':equipment_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            spliceclosure = processing.run("native:extractbyexpression", {'INPUT':spliceclosure_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            structure = processing.run("native:extractbyexpression", {'INPUT':structure_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            riser = processing.run("native:extractbyexpression", {'INPUT':riser_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            slackloop = processing.run("native:extractbyexpression", {'INPUT':slackloop_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            pole = processing.run("native:extractbyexpression", {'INPUT':pole_clip, 'EXPRESSION': f'"workorderid" = \'{workorderid}\' and "status" = \'FDA\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            permit = processing.run("native:extractbylocation", {'INPUT':permit_clip,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(project_layer.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            progressBar.setValue(10)
            # Distance Calculator 
            distance_calculator = QgsDistanceArea()
            distance_calculator.setEllipsoid(QgsProject.instance().ellipsoid())
            distance_calculator.setSourceCrs(QgsProject.instance().crs(), QgsProject.instance().transformContext())
            def footage_calculator(layer):
                total_footage = 0
                for f in layer.getFeatures():
                    geom = f.geometry()
                    length_meters = distance_calculator.measureLength(geom)
                    length_feet = length_meters * 3.28084  
                    total_footage += length_feet
                return total_footage

            #-------------------------------------------------------------------------------------
            # Install Method - Linear Footages Section
            #-------------------------------------------------------------------------------------
            cover_8in = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"installmethod" = \'ShallowTrenchHardscape\' and "p6id" = \'8\"\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            cover_12in = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"installmethod" = \'ShallowTrenchHardscape\' and "p6id" = \'12\"\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            cover_16in  = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"installmethod" = \'ShallowTrenchHardscape\' and "p6id" = \'16\"\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            bore = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"installmethod" = \'Bore\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E3'] = footage_calculator(cover_8in)
            ws['E4'] = footage_calculator(cover_12in)
            ws['E5'] = footage_calculator(cover_16in)
            ws['E6'] = footage_calculator(bore)
            #ws['E7'] = No Standard Bore
            #ws['E8'] = No Large Bore
            shallowTrench = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"installmethod" = \'ShallowTrenchSoftscape\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            trench = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"installmethod" = \'Trench\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E9'] = footage_calculator(shallowTrench)
            ws['E10'] = footage_calculator(trench)
            #ws['E11'] = Conduit Proofing
            street_crossings = processing.run("native:lineintersections", {'INPUT':path,'INTERSECT':converse_roads_layer,'INPUT_FIELDS':[],'INTERSECT_FIELDS':[],'INTERSECT_FIELDS_PREFIX':'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E12'] = street_crossings.featureCount()
            bore = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"installmethod" = \'Bore\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            bore_locations = processing.run("native:dissolve", {'INPUT':bore,'FIELD':[],'SEPARATE_DISJOINT':True,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E13'] = bore_locations.featureCount()
            fcp_crossings = processing.run("native:extractbyexpression", {'INPUT':permit, 'EXPRESSION': f'"name" = \'FCP\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E14']  = fcp_crossings.featureCount()
            fc_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E15'] = footage_calculator(fc_UG)
            path_8 = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"p6id" = \'8\"\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            path_12 = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"p6id" = \'12\"\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            vaults = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"structureform" = \'Vault\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            processing.run("native:selectwithindistance", {'INPUT':vaults,'REFERENCE':path_8,'DISTANCE':5e-05,'METHOD':0})
            ws['E16'] = vaults.selectedFeatureCount()
            processing.run("native:selectwithindistance", {'INPUT':vaults,'REFERENCE':path_12,'DISTANCE':5e-05,'METHOD':0})
            ws['E17'] = vaults.selectedFeatureCount()
            conduit_stub = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"stub_out" = \'Y\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E18'] = conduit_stub.featureCount()
            progressBar.setValue(20)
            #-------------------------------------------------------------------------------------
            # FOC and Conduit
            #-------------------------------------------------------------------------------------
            fc24_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'24\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc24_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'24\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc24_AE_slack = processing.run("native:extractbyexpression", {'INPUT':slackloop, 'EXPRESSION': f'"cablecapacity" = \'24\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc24_UG_slack = processing.run("native:extractbyexpression", {'INPUT':slackloop, 'EXPRESSION': f'"cablecapacity" = \'24\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            
            AE_total = footage_calculator(fc24_AE)+\
                    fc24_AE_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            UG_total = footage_calculator(fc24_UG) +\
                    fc24_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            ws['E21'] = UG_total
            ws['E22'] = AE_total

            fc48_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'48\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc48_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'48\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc48_AE_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'48\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc48_UG_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'48\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            
            AE_total = footage_calculator(fc48_AE) +\
                    fc48_AE_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            UG_total = footage_calculator(fc48_UG) +\
                    fc48_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            ws['E23'] = UG_total
            ws['E24'] = AE_total

            fc96_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'96\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc96_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'96\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc96_AE_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'96\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc96_UG_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'96\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            
            AE_total = footage_calculator(fc96_AE) +\
                    fc96_AE_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            UG_total = footage_calculator(fc96_UG) +\
                    fc96_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            '''ws['B25'] = f'{fc96_UG.aggregate(QgsAggregateCalculator.Sum, "calculatedlength")[0]} +\
                    {fc96_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0]} +\
                    {(riser.featureCount()*25)}'''
            ws['E25'] = UG_total
            ws['E26'] = AE_total

            fc144_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'144\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc144_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'144\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc144_AE_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'144\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc144_UG_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'144\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            
            AE_total = footage_calculator(fc144_AE) +\
                    fc144_AE_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            UG_total = footage_calculator(fc144_UG) +\
                    fc144_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            ws['E27'] = UG_total
            ws['E28'] = AE_total

        
            fc432_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'432\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc432_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'432\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc432_AE_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'432\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc432_UG_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'432\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            
            AE_total = footage_calculator(fc432_AE) +\
                    fc432_AE_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            UG_total = footage_calculator(fc432_UG) +\
                    fc432_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            ws['E29'] = UG_total
            ws['E30'] = AE_total

            fc864_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'864\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc864_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'864\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc864_AE_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'864\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc864_UG_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'864\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            
            AE_total = footage_calculator(fc864_AE) +\
                    fc864_AE_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            UG_total = footage_calculator(fc864_UG) +\
                    fc864_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            ws['E31'] = UG_total
            ws['E32'] = AE_total
            #??Mixed Trench???
            conduit_tracer_wire = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"installmethod" = \'DirectBury\' and "comments" = \'7-Way\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit_2in = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'2.0inch\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit_125in = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'1.25inch\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit_18_14 = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'18mm_14mm\' and "comments" != \'7-Way\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit_18_14_7Way = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'18mm_14mm\' and "comments" = \'7-Way\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit_12710 = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'12.7mm_10mm\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E33'] = ws['E15'].value - footage_calculator(conduit_tracer_wire)
            ws['E34'] = footage_calculator(conduit_2in)
            ws['E35'] = footage_calculator(conduit_125in)
            ws['E36'] = footage_calculator(conduit_18_14_7Way)
            ws['E37'] = footage_calculator(conduit_18_14)
            ws['E38'] = footage_calculator(conduit_12710)
            progressBar.setValue(30)
            #-------------------------------------------------------------------------------------
            # Enclosures
            #-------------------------------------------------------------------------------------
            # splitratio SPL16, SPL64, no 1x or 2x
            #ignore C40
            splitters = processing.run("native:extractbyexpression", {'INPUT':equipment, 'EXPRESSION': f'"splitratio" = \'SPL64\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            FOSC_600 = processing.run("native:extractbyexpression", {'INPUT':spliceclosure, 'EXPRESSION': f'"closuresize" = \'600\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            FOSC_450D = processing.run("native:extractbyexpression", {'INPUT':spliceclosure, 'EXPRESSION': f'"closuresize" = \'D\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            FOSC_450B = processing.run("native:extractbyexpression", {'INPUT':spliceclosure, 'EXPRESSION': f'"closuresize" = \'B\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            FOSC_450A = processing.run("native:extractbyexpression", {'INPUT':spliceclosure, 'EXPRESSION': f'"closuresize" = \'A\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            SLiC = processing.run("native:extractbyexpression", {'INPUT':spliceclosure, 'EXPRESSION': f'"closuresize" = \'SLIC\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            Coyote = processing.run("native:extractbyexpression", {'INPUT':spliceclosure, 'EXPRESSION': f'"closuresize" = \'DROP\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            DTC_8 = processing.run("native:extractbyexpression", {'INPUT':spliceclosure, 'EXPRESSION': f'"closuresize" = \'DTC-8\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E41'] = splitters.featureCount()
            ws['E42'] = FOSC_600.featureCount()
            ws['E43'] = FOSC_450D.featureCount()
            ws['E44'] = FOSC_450B.featureCount()
            ws['E45'] = FOSC_450A.featureCount()
            ws['E46'] = SLiC.featureCount()
            ws['E47'] = Coyote.featureCount()
            ws['E48'] = DTC_8.featureCount()

            af_fiber = [f for f in fibercable.getFeatures() if f['category'] == 'AF']
            unique_fiber = set(f['cablename'] for f in af_fiber)
            ws['E49'] = len(unique_fiber)
            #ignore C50
            #ignore C51


            progressBar.setValue(50)
            #-------------------------------------------------------------------------------------
            # Vaults
            #-------------------------------------------------------------------------------------
            DV = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'DV\' and "name" like \'%Carson%\' and "rating" != \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            XS = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'DV\' and "name" not like \'%Carson%\' and "rating" != \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            SV = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'SV\' and "rating" != \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            LV = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'LV\' and "rating" != \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            XLV = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'XLV\' and "rating" != \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E57'] = DV.featureCount()
            ws['E58'] = XS.featureCount()
            ws['E59'] = SV.featureCount()
            ws['E60'] = LV.featureCount()
            ws['E61'] = XLV.featureCount()
            progressBar.setValue(60)
            #-------------------------------------------------------------------------------------
            # Aerial
            #-------------------------------------------------------------------------------------
            #Defualt to 'Front' if strand exists, Use "path" layer since it has the "Easement" field
            strand_front = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"placement" = \'PLACEMENT_AERIAL\' and "easement" in (NULL, \'Front\')','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            strand_rear = processing.run("native:extractbyexpression", {'INPUT':path, 'EXPRESSION': f'"placement" = \'PLACEMENT_AERIAL\' and "easement" =\'Rear\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']

            ws['E64'] = footage_calculator(strand_front)
            ws['E65'] = footage_calculator(strand_rear)
            '''Aerial Cable Footage - New vs Overlash'''
            #New - Dissolved footage
            #Overlash = All footage - Dissolved Footage
            fc_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc_AE_dissolved = processing.run("native:dissolve", {'INPUT':fc_AE,'FIELD':[],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            fc_sum_length_feet_AE = footage_calculator(fc_AE_dissolved)
            ws['E66'] = fc_sum_length_feet_AE
            ws['E67'] = footage_calculator(fc_AE)- fc_sum_length_feet_AE
            ws['E68'] = riser.featureCount()
            ws['E69'] = pole.featureCount()
            #ws['E63'] = #where are anchors?
            progressBar.setValue(70)
            #-------------------------------------------------------------------------------------
            # Vaults - Exceptions
            #-------------------------------------------------------------------------------------
            DVT22 = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'DV\' and "rating" = \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            SVT22 = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'SV\' and "rating" = \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            LVT22 = processing.run("native:extractbyexpression", {'INPUT':structure, 'EXPRESSION': f'"vaultsize" = \'LV\' and "rating" = \'Tier22\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']

            ws['E72'] = DVT22.featureCount()
            ws['E73'] = SVT22.featureCount()
            ws['E74'] = LVT22.featureCount()
            progressBar.setValue(80)
            #-------------------------------------------------------------------------------------
            # MISC
            #-------------------------------------------------------------------------------------
            #OLT = 
            #ws['E77'] = OLT.featureCount()
            conduit_1in = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'1.0inch\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit_34in = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'0.75inch\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            conduit_12in = processing.run("native:extractbyexpression", {'INPUT':conduit, 'EXPRESSION': f'"diameter" = \'0.5inch\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            ws['E78'] = conduit_1in.featureCount()
            ws['E79'] = conduit_34in.featureCount()
            ws['E80'] = conduit_12in.featureCount()

            fc288_AE = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'288\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc288_UG = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'288\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc288_AE_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'288\' and "placement" = \'PLACEMENT_AERIAL\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            fc288_UG_slack = processing.run("native:extractbyexpression", {'INPUT':fibercable, 'EXPRESSION': f'"cablecapacity" = \'288\' and "placement" = \'PLACEMENT_UNDERGROUND\'','OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            
            AE_total = footage_calculator(fc288_AE)+\
                    fc288_AE_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            UG_total = footage_calculator(fc288_UG) +\
                    fc288_UG_slack.aggregate(QgsAggregateCalculator.Sum, "measuredlength")[0] +\
                    (riser.featureCount()*25)
            ws['E81'] = UG_total
            ws['E82'] = AE_total

            progressBar.setValue(90)
            #-------------------------------------------------------------------------------------
            # Save the Workbook
            #-------------------------------------------------------------------------------------
            
            wb.save(f'{outputfolder}\\{workorderid}_Rake-Off.xlsx')
        sheets_to_delete = ['SAT','AUS', 'DEN', 'AUS-T2P']
        for sheet_name in sheets_to_delete:
            if sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                wb.remove(ws)
        grid_sheets = [ ws for ws in wb.worksheets if ws.title.isdigit()]
        grid_sheets.sort(key=lambda ws: int(ws.title))
        wb._sheets = [wb[workorderid]] + grid_sheets
        wb.save(f'{outputfolder}\\{workorderid}_Rake-Off.xlsx')

        dbox.append(f'Output File: {outputfolder}\\{workorderid}_Rake-Off.xlsx')
        dbox.append(validFormat.format(f'Google BOM (Rake-Off) has been succesfully completed.'))
        progressBar.setValue(100)
        
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  