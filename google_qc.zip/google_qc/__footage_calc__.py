# -*- coding: utf-8 -*-
"""
Created on Monday, July 21, 2025
Vero QC LLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __footage_calc__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat):

    try:
        dbox.append(f'Footage Calculation at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()

        #layers
        proj_lyr = project.mapLayersByName('project')[0]
        fibercable= project.mapLayersByName('fibercable')[0]
        path = project.mapLayersByName('path')[0]
        workorderid = bound
        dbox.append(f'---{workorderid}---')
        #--------------------------------------
        
        try:
            processing.run("qgis:selectbyattribute", {'INPUT':proj_lyr, 'FIELD': 'workorderid', 'OPERATOR': 0, 'VALUE': workorderid, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            #F0-2 Billing Footage: Sum of dissolved footage of F0-2 Fibercable within project boundary: Dissolve fibercable whose category is equal to DF, BB, and TIER2. Clip to project boundary. Sum re-calculated lengths.
            FC_F02 = processing.run("native:extractbyexpression", {'INPUT':fibercable ,'EXPRESSION':f'"workorderid" = \'{workorderid}\' and "category" in (\'DF\', \'BB\',\'TIER2\')','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            FC_F02_clip = processing.run("native:clip", {'INPUT':FC_F02,'OVERLAY':QgsProcessingFeatureSourceDefinition(proj_lyr.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            FC_F02_dissolved = processing.run("native:dissolve", {'INPUT':FC_F02_clip,'FIELD':["placement"],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            
            distance_calculator = QgsDistanceArea()
            distance_calculator.setEllipsoid(QgsProject.instance().ellipsoid())
            distance_calculator.setSourceCrs(QgsProject.instance().crs(), QgsProject.instance().transformContext())
            #distance_calculator.setEllipsoidalMode(True)

            FC_F02_sum_length_feet_AE = 0
            FC_F02_sum_length_feet_UG = 0
            FC_F02_sum_length_feet_UNK = 0
            for f in FC_F02_dissolved.getFeatures():
                geom = f.geometry()
                length_meters = distance_calculator.measureLength(geom)
                length_feet = length_meters * 3.28084
                if f['placement'] == 'PLACEMENT_AERIAL':
                    FC_F02_sum_length_feet_AE += length_feet
                elif f['placement'] == 'PLACEMENT_UNDERGROUND':
                    FC_F02_sum_length_feet_UG += length_feet
                else:
                    FC_F02_sum_length_feet_UNK += length_feet
            dbox.append(f'----F0-2 Billing Footage---- \n\
                        Aerial Footage: {FC_F02_sum_length_feet_AE:,.2f} ft\n\
                        Underground Footage: {FC_F02_sum_length_feet_UG:,.2f} ft\n\
                        Undesignated Footage: {FC_F02_sum_length_feet_UNK:,.2f} ft \n\
                        Combined Dissolved Footage (AE+UG): {FC_F02_sum_length_feet_AE+FC_F02_sum_length_feet_UG:,.2f} ft')
            #(Row 22) Total Project Footage: Sum of calculated footage of path layer that matches the project's workorderid (do not take into account path status)
            '''processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\'','METHOD':0})['OUTPUT']
            path_footage = path.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= path.selectedFeatureIds())[0]

            processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and category not in (\'DROP\')','METHOD':0})['OUTPUT']
            processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and hierarchy in (\'AF\', \'BB\', \'DF\')','METHOD':0})['OUTPUT']
            processing.run("native:selectbylocation", {'INPUT':fibercable,'PREDICATE':[5],'INTERSECT':QgsProcessingFeatureSourceDefinition(path.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':2})
            FC_trim_dissolved = processing.run("native:dissolve", {'INPUT':QgsProcessingFeatureSourceDefinition(fibercable.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'FIELD':[],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            FC_trim_sum_length_feet = 0
            for f in FC_trim_dissolved.getFeatures():
                geom = f.geometry()
                length_meters = distance_calculator.measureLength(geom)
                length_feet = length_meters * 3.28084
                FC_trim_sum_length_feet += length_feet
            ws2.cell(22, 2).value = path_footage + FC_trim_sum_length_feet
            ws2.cell(23,2).value = f'{str(path_footage)} + {str(FC_trim_sum_length_feet)} ' '''
            FC = processing.run("native:extractbyexpression", {'INPUT':fibercable ,'EXPRESSION':f'"workorderid" = \'{workorderid}\' and "category" not in (\'DROP\')','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            FC_dissolved = processing.run("native:dissolve", {'INPUT':FC,'FIELD':["placement"],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            FC_sum_length_feet_AE = 0
            FC_sum_length_feet_UG = 0
            FC_sum_length_feet_UNK = 0
            for f in FC_dissolved.getFeatures():
                geom = f.geometry()
                length_meters = distance_calculator.measureLength(geom)
                length_feet = length_meters * 3.28084
                if f['placement'] == 'PLACEMENT_AERIAL':
                    FC_sum_length_feet_AE += length_feet
                elif f['placement'] == 'PLACEMENT_UNDERGROUND':
                    FC_sum_length_feet_UG += length_feet
                else:
                    FC_sum_length_feet_UNK += length_feet
            dbox.append(f'----Total Project Footage---- \n\
                        Aerial Footage: {FC_sum_length_feet_AE:,.2f} ft\n\
                        Underground Footage: {FC_sum_length_feet_UG:,.2f} ft\n\
                        Undesignated Footage: {FC_sum_length_feet_UNK:,.2f} ft \n\
                        Combined Dissolved Footage (AE+UG): {FC_sum_length_feet_AE+FC_sum_length_feet_UG:,.2f} ft')
            
            paths = processing.run("native:extractbyexpression", {'INPUT':path ,'EXPRESSION':f'workorderid = \'{workorderid}\'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            Path_sum_length_feet_AE = 0
            Path_sum_length_feet_UG = 0
            Path_sum_length_feet_UNK = 0
            for f in paths.getFeatures():
                geom = f.geometry()
                length_meters = distance_calculator.measureLength(geom)
                length_feet = length_meters * 3.28084
                if f['placement'] == 'PLACEMENT_AERIAL':
                    Path_sum_length_feet_AE += length_feet
                elif f['placement'] == 'PLACEMENT_UNDERGROUND':
                    Path_sum_length_feet_UG += length_feet
                else:
                    Path_sum_length_feet_UNK += length_feet
            dbox.append(f'----Total Path Footage---- \n\
                        Aerial Footage: {Path_sum_length_feet_AE:,.2f} ft\n\
                        Underground Footage: {Path_sum_length_feet_UG:,.2f} ft\n\
                        Undesignated Footage: {Path_sum_length_feet_UNK:,.2f} ft \n\
                        Combined Dissolved Footage (AE+UG): {Path_sum_length_feet_AE+Path_sum_length_feet_UG:,.2f} ft')
            
            
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
    

                 

