# -*- coding: utf-8 -*-
"""
Created on Tues July 25, 2025
Vero QC - geometry Checks
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__network_trace__ import __network_trace__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject,QgsSpatialIndex, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsPointXY, QgsVectorLayer, QgsVectorLayerJoinInfo,\
                     edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest, QgsFeature,QgsField, QgsFields,QgsCoordinateReferenceSystem
from qgis import processing
from qgis.utils import iface
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime
canvas = iface.mapCanvas()

def __invalid_geoms__(project_name, dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks):
    print('invalid geoms')
    full_start_time = datetime.now()
    dbox.append('CHECKING GEOMETRIES')
    dbox.append('____________________________________________________________________________________________')
    invalid = False
    dbox.append(str(geom_checks))
        
    def check_and_export_geometry_issues(layer):
        if not layer or not layer.isValid():
            dbox.append(f"Layer '{layer.name()}' is not valid.")
            return

        expected_type = QgsWkbTypes.geometryType(layer.wkbType())
        type_name = QgsWkbTypes.displayString(layer.wkbType())
        dbox.append(f"\n🔍 Checking layer: {layer.name()} ({type_name})")

        null_ids = []
        empty_ids = []
        invalid_ids = []
        type_mismatch_ids = []
        error_features = []

        for feature in layer.getFeatures(QgsFeatureRequest().setSubsetOfAttributes([])):
            fid = feature.id()
            geom = feature.geometry()

            if geom is None or geom.isNull():
                null_ids.append(fid)
                #error_features.append((feature, "Null")) #Automatically Deleted
                continue

            if geom.isEmpty():
                empty_ids.append(fid)
                #error_features.append((feature, "Empty")) #Automatically Deleted

            if not geom.isGeosValid():
                invalid_ids.append(fid)
                error_features.append((feature, "Invalid"))

            if QgsWkbTypes.geometryType(geom.wkbType()) != expected_type:
                type_mismatch_ids.append(fid)
                error_features.append((feature, "TypeMismatch"))
        
        #delete Null and Empty Geometries
        delete_ids = list(set(null_ids + empty_ids))
        
        if delete_ids:
            if not layer.isEditable():
                layer.startEditing()
            res = layer.deleteFeatures(delete_ids)
            layer.commitChanges()
        dbox.append(f"🗑️ Deleted {len(delete_ids)} features with Null or Empty geometries.")

        # Select problematic features
        all_problem_ids = list(set(invalid_ids + type_mismatch_ids))
        layer.selectByIds(all_problem_ids)
        dbox.append(f"  Invalid geometries: {len(invalid_ids)}")
        dbox.append(f"  Type mismatches: {len(type_mismatch_ids)}")
        dbox.append(f"  Total selected: {len(all_problem_ids)}")

        # Optional: Export to memory layer
        if error_features:
            export_errors_to_memory_layer(layer, error_features)

    def export_errors_to_memory_layer(source_layer, error_features):
        crs = source_layer.crs()
        geom_type = QgsWkbTypes.displayString(source_layer.wkbType())
        mem_layer = QgsVectorLayer(f"{geom_type}?crs={crs.authid()}", f"{source_layer.name()}_GeometryErrors", "memory")
        mem_provider = mem_layer.dataProvider()

        # Copy fields + add error type field
        fields = source_layer.fields()
        fields.append(QgsField("ErrorType", QVariant.String))
        mem_provider.addAttributes(fields)
        mem_layer.updateFields()

        new_features = []
        for feature, error_type in error_features:
            new_feat = QgsFeature()
            new_feat.setGeometry(feature.geometry())
            attrs = feature.attributes() + [error_type]
            new_feat.setAttributes(attrs)
            new_features.append(new_feat)

        mem_provider.addFeatures(new_features)
        QgsProject.instance().addMapLayer(mem_layer)
        print(f"✅ Exported {len(new_features)} error features to memory layer: {mem_layer.name()}")

    def feature_snapping_direction_overlaps(project_name):
        # Parameters
        SNAP_TOLERANCE = 0.0000137  # degrees ~=4.315 feet

        # Layers - Lines
        path_layer = QgsProject.instance().mapLayersByName("path")[0]
        conduit_layer = QgsProject.instance().mapLayersByName("conduit")[0]
        strand_layer = QgsProject.instance().mapLayersByName("strand")[0]
        fiber_layer = QgsProject.instance().mapLayersByName("fibercable")[0]

        # Layers = Points
        hutpoint_layer = QgsProject.instance().mapLayersByName("hutpoint")[0]
        riser_layer = QgsProject.instance().mapLayersByName("riser")[0]
        slackloop_layer = QgsProject.instance().mapLayersByName("slackloop")[0]
        equipment_layer = QgsProject.instance().mapLayersByName("equipment")[0]
        spliceclosure_layer = QgsProject.instance().mapLayersByName("spliceclosure")[0]
        pole_layer = QgsProject.instance().mapLayersByName("pole")[0]
        structure_layer = QgsProject.instance().mapLayersByName("structure")[0]
        site_layer = QgsProject.instance().mapLayersByName("address")[0] #final address?
        
        # Layers - Polygons
        project_layer = QgsProject.instance().mapLayersByName("project")[0]
        demarcarea_layer = QgsProject.instance().mapLayersByName("demarcarea")[0]
        permit_layer = QgsProject.instance().mapLayersByName("permit_polygons")[0]
        
        pole_index = QgsSpatialIndex(pole_layer.getFeatures())
        structure_index = QgsSpatialIndex(structure_layer.getFeatures())
        hutpoint_index = QgsSpatialIndex(hutpoint_layer.getFeatures())


        #Selected Boundary
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':project_layer, 'FIELD': 'workorderid', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        
        # Build spatial indexes
        pole_redux = processing.run("native:extractbylocation", {'INPUT':pole_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        structure_redux = processing.run("native:extractbylocation", {'INPUT':structure_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        hutpoint_redux = processing.run("native:extractbylocation", {'INPUT':hutpoint_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']

        pole_redux_index = QgsSpatialIndex(pole_redux.getFeatures())
        structure_redux_index = QgsSpatialIndex(structure_redux.getFeatures())
        hutpoint_redux_index = QgsSpatialIndex(hutpoint_redux.getFeatures())



       # Helper: check if point is snapped to pole or structure_point
        def is_snapped(point_geom, type = None):
            #buffer = point_geom.buffer(SNAP_TOLERANCE, 5)
            buffer = point_geom
            pole_ids = pole_redux_index.intersects(buffer.boundingBox())
            structure_ids = structure_redux_index.intersects(buffer.boundingBox())
            hutpoint_ids = hutpoint_redux_index.intersects(buffer.boundingBox())
            #site_ids = site_index.intersects(buffer.boundingBox())
            #borePit_ids = borePit_index.intersects(buffer.boundingBox())
            return pole_ids or structure_ids or hutpoint_ids

        def snap_point_to_nearest(point_geom, type = None):
            buffer = point_geom.buffer(SNAP_TOLERANCE, 5)
            nearest = None
            min_dist = float("inf")
            if type == 'BB':
                valid_endpoints = [(pole_layer, pole_index), (structure_layer, structure_index), (hutpoint_layer, hutpoint_index)]

            else:
                valid_endpoints = [(pole_redux, pole_redux_index), (structure_redux, structure_redux_index), (hutpoint_redux, hutpoint_redux_index)]

            for layer, index in valid_endpoints:
                ids = index.intersects(buffer.boundingBox())
                for fid in ids:
                    feat = next(layer.getFeatures(QgsFeatureRequest(fid)))
                    candidate_geom = feat.geometry()
                    dist = point_geom.distance(candidate_geom)
                    if dist < min_dist:
                        min_dist = dist
                        nearest = candidate_geom

            return nearest if nearest else point_geom  # fallback to original

        def validate_and_snap_line_endpoints(layer, layer_name):
            if any("Fix Snapping" in x for x in geom_checks):
                layer.startEditing()
            if any("Snapping" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = layer.getSelectedFeatures()
                total = layer.selectedFeatureCount()
            else:
                features = layer.getFeatures()
                total = layer.featureCount()
            
            for idx, feature in enumerate(features):

                geom = feature.geometry()
                globalid = feature["globalid"]

                if not geom or geom.isEmpty() or geom.type() != QgsWkbTypes.LineGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {globalid} has invalid geometry.")
                    continue

                # Handle multipart geometries
                if QgsWkbTypes.isMultiType(geom.wkbType()):
                    multiline = geom.asMultiPolyline()
                    if not multiline:
                        dbox.append(f"[SKIP] {layer_name} Feature {globalid} has zero-part geometry.")
                        continue
                    if len(multiline) > 1:
                        dbox.append(f"[SKIP] {layer_name} Feature {globalid} has multi-part geometry.")
                        continue
                    line = multiline[0]  # Single part
                else:
                    line = geom.asPolyline()

                start_pt = QgsGeometry.fromPointXY(line[0])
                end_pt = QgsGeometry.fromPointXY(line[-1])


                snapped_start = start_pt
                snapped_end = end_pt
                changed = False

                if layer_name in ['path', 'fibercable', 'conduit'] and feature['hierarchy'] in ['BB']:
                    type = 'BB'
                else:
                    type = None
                if not is_snapped(start_pt, type):
                    if any("Fix Snapping" in x for x in geom_checks):
                        snapped_start = snap_point_to_nearest(start_pt, type)
                        if snapped_start != start_pt:
                            changed = True
                            dbox.append(f"[FIXED] {layer_name} Feature {globalid} start point snapped.")
                            start_pt = snapped_start
                        else:
                            dbox.append(f"[ERROR] {layer_name} Feature {globalid} start point not snapped, nearest valid point not found within 5 feet.")
                    else:
                        dbox.append(f"[ERROR] {layer_name} Feature {globalid} start point not snapped.")
                if not is_snapped(end_pt, type):
                    if any("Fix Snapping" in x for x in geom_checks):
                        snapped_end = snap_point_to_nearest(end_pt, type)
                        if snapped_end != end_pt:
                            changed = True
                            dbox.append(f"[FIXED] {layer_name} Feature {globalid} end point snapped.")
                            end_pt = snapped_end
                        else:
                            dbox.append(f"[ERROR] {layer_name} Feature {globalid} end point not snapped, nearest valid point not found within 5 feet.")
                    else:
                         dbox.append(f"[ERROR] {layer_name} Feature {globalid} end point not snapped.")
                if any("Fix Snapping" in x for x in geom_checks):
                    if changed:
                        #points = geom.asPolyline()
                        line[0] = snapped_start.asPoint()
                        line[-1] = snapped_end.asPoint()
                        new_geom = QgsGeometry.fromPolylineXY(line)
                        layer.changeGeometry(feature.id(), new_geom)

                if idx % 10 == 0:
                    progress = int((idx / total) * 100)
                    QCoreApplication.processEvents()
                    functionProgressBar.setValue(progress)


            if any("Fix Snapping" in x for x in geom_checks):
                
                layer.commitChanges()
                dbox.append('Changes Committed')

             #"Fix Directionality Errors"    
            '''if layer_name == 'fibercable':
                
                if any("Fix Directionality" in x for x in geom_checks):
                    __network_trace__(dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks)
                else:
                    start_points_by_name = {}
                    end_points_by_name = {}
                    if name not in [None, ''] and feature['cable_category'] != 2: #if not not drop...
                        if name in start_points_by_name:
                            if start_pt.equals(start_points_by_name[name]):
                                layer, globalid = get_snapped_globalid(start_pt)
                                dbox.append(f"[ERROR] fiber_cable '{name}' duplicate start/start at {layer} globalid {globalid}")
                        else:
                            start_points_by_name[name] = start_pt

                        if name in end_points_by_name:
                            if end_pt.equals(end_points_by_name[name]):
                                layer, globalid = get_snapped_globalid(end_pt)
                                dbox.append(f"[ERROR] fiber_cable '{name}' duplicate end/end at {layer} globalid {globalid}")
                        else:
                            end_points_by_name[name] = end_pt
                    elif name not in [None, ''] and feature['cable_category'] == 2: #is drop, but with a name
                        dbox.append(f"[ERROR] fiber_cable '{name}' has 'drop' category.")
                    elif name in [None, ''] and feature['cable_category'] == 2:
                        pass     '''

        # Helper: get globalid of snapped point
        def get_snapped_globalid(point_geom):
            buffer = point_geom.buffer(SNAP_TOLERANCE, 5)
            for layer, index in [(pole_redux, pole_index), (structure_redux, structure_index), (hutpoint_redux, hutpoint_index)]:
                ids = index.intersects(buffer.boundingBox())
                for fid in ids:
                    feat = next(layer.getFeatures(QgsFeatureRequest(fid)))
                    if feat.geometry().intersects(buffer):
                        return layer.name(), feat["globalid"]
            return None, None

        # Helper: validate point snapping
        def validate_point_layer(layer, layer_name):
            if any("Fix Snapping" in x for x in geom_checks):
                if layer.isEditable():
                    layer.commitChanges()
                layer.startEditing()
            if any("Snapping" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = layer.getSelectedFeatures()
            else:
                features = layer.getFeatures()
            

            for feature in features:
                geom = feature.geometry()
                globalid = feature["globalid"]

                if not geom or geom.isEmpty() or geom.type() != QgsWkbTypes.PointGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {globalid} has invalid geometry.")
                    continue

                if not is_snapped(geom):
                    if any("Fix Snapping" in x for x in geom_checks):
                        snapped_start = snap_point_to_nearest(geom)
                        if snapped_start != geom:
                            changed = True
                            dbox.append(f"[FIXED] {layer_name} Feature {globalid} point snapped.")
                            success = layer.changeGeometry(feature.id(), snapped_start)
                            if not success:
                                print(f"[ERROR] Failed to update geometry for feature {feature["globalid"]}")
                        else:
                            changed= False
                            dbox.append(f"[ERROR] {layer_name} Feature {globalid} point not snapped, nearest valid point not found within 5 feet.")
                    else:
                        dbox.append(f"[ERROR] {layer_name} Feature {globalid} point not snapped.")
            
            if any("Fix Snapping" in x for x in geom_checks):
                layer.commitChanges()   
                dbox.append('Changes Comittted')             
            
        def validate_polygon_layer(layer, layer_name):
            if any("Snapping" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = list(layer.getSelectedFeatures())
            else:
                features = list(layer.getFeatures())

            id_to_globalid = {f.id(): f["globalid"] for f in features}
            globalid_to_feature = {f["globalid"]: f for f in features}

            #feature_dict = {f["globalid"]: f for f in features}
            index = QgsSpatialIndex(layer.getFeatures())  # Build index for fast overlap checks

            for feat in features:
                globalid = feat["globalid"]
                geom = feat.geometry()
                if not geom or geom.isEmpty() or geom.type() != QgsWkbTypes.PolygonGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {globalid} has invalid geometry.")
                    continue
                # Check single-part
                if geom.isMultipart():
                    if len(geom.asGeometryCollection()) == 1:
                        geom = geom.asGeometryCollection()[0]
                    else:
                        dbox.append(f"[ERROR] {layer_name} Feature {globalid} is multipart.")
                        continue
                # Check for interior overlaps
                if layer.name() == 'Cabinet_Boundary':
                    if any(x in feat['fda_name'] for x in ['F0', 'F1']):
                        continue #skip if not F2. F1 and F0 can overlap.
                bbox = geom.boundingBox()
                candidate_ids = index.intersects(bbox)

                for cid in candidate_ids:
                    other_globalid = id_to_globalid.get(cid)
                    if other_globalid == globalid:
                        continue  # Skip self

                    other_feat = globalid_to_feature.get(other_globalid)
                    if not other_feat:
                        continue

                    other_geom = other_feat.geometry()

                    if not other_geom or other_geom.isEmpty():
                        continue

                    # Check if interiors intersect (not just touching)
                    if geom.intersects(other_geom) and not geom.touches(other_geom):
                        dbox.append(f"[ERROR] {layer_name} Feature {globalid} overlaps with Feature {other_feat["globalid"]}")


        def validate_no_overlaps(layer, layer_name):
            if any("Overlaps" in x for x in geom_checks):
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = layer.getSelectedFeatures()
                total = layer.selectedFeatureCount()
            else:
                features = layer.getFeatures()
                total = layer.featureCount()
            index = QgsSpatialIndex(features)

            id_to_globalid = {f.id(): f["globalid"] for f in layer.getSelectedFeatures()}
            globalid_to_feature = {f["globalid"]: f for f in layer.getSelectedFeatures()}
            id_to_geom = {f.id(): f.geometry() for f in layer.getSelectedFeatures()}

            errors = []
            dbox.append(str(total))
            dbox.append(layer.name())

            for idx, feature in enumerate(layer.getSelectedFeatures(), 1):
                geom = feature.geometry()
                globalid = feature["globalid"]
                if not geom or geom.isEmpty():# or geom.type() != QgsWkbTypes.PolygonGeometry:
                    dbox.append(f"[SKIP] {layer_name} Feature {globalid} has invalid geometry.")
                    continue
              # Check single-part
                if geom.isMultipart():
                    if len(geom.asGeometryCollection()) == 1:
                        geom = geom.asGeometryCollection()[0]
                    else:
                        dbox.append(f"[ERROR] {layer_name} Feature {globalid} is multipart.")
                        continue
                 # Check for interior overlaps
                if layer.name() == 'Cabinet_Boundary':
                    if any(x in feature['fda_name'] for x in ['F0', 'F1']):
                        continue #skip if not F2. F1 and F0 can overlap.

                bbox = geom.boundingBox()
                candidate_ids = index.intersects(bbox)
                
                for cid in candidate_ids:
                    if cid == feature.id():
                        continue  # Skip self

                    other_geom = id_to_geom[cid]
                   
                    if not other_geom or other_geom.isEmpty():
                        dbox.append('not other geom')
                        continue

                    if layer.name() != 'Permits':
                        # Disallow any intersection that isn't just touching
                        if (geom.intersects(other_geom) and not geom.touches(other_geom)) or geom.equals(other_geom):
                            dbox.append(f"[ERROR] {layer_name} Feature {globalid} overlaps with Feature {id_to_globalid[cid]}")
                    else:
                        #Permits may overlap, but cannot be the same geometry
                        if geom.equals(other_geom):
                            dbox.append(f"[ERROR] {layer_name} Feature {globalid} geometry is same as Feature {id_to_globalid[cid]}")

        # Validate other layers, #we do not validate pole or structure_point features since those are considered to be the backbone structure of the network. Proximity is checked in attributes.
        if any("Snapping" in x for x in geom_checks) or any("Fix" in x for x in geom_checks):
            #lines
            progressBar.setValue(5)
            dbox.append('-Path-')
            validate_and_snap_line_endpoints(path_layer, "path")
            QCoreApplication.processEvents()
            progressBar.setValue(15)
            dbox.append('-Conduit-')
            validate_and_snap_line_endpoints(conduit_layer, "conduit")
            QCoreApplication.processEvents()
            progressBar.setValue(15)
            dbox.append('-Strand-')
            validate_and_snap_line_endpoints(strand_layer, "strand")
            QCoreApplication.processEvents()
            progressBar.setValue(15)
            dbox.append('-Fibercable')
            validate_and_snap_line_endpoints(fiber_layer, "fibercable")
            QCoreApplication.processEvents()
            progressBar.setValue(45)
            #points
            dbox.append('-Splicing-')
            validate_point_layer(spliceclosure_layer, "spliceclosure")
            QCoreApplication.processEvents()
            progressBar.setValue(20)
            dbox.append('-Equipment-')
            validate_point_layer(equipment_layer, "equipment")
            QCoreApplication.processEvents()
            progressBar.setValue(25)
            dbox.append('-Riser-')
            validate_point_layer(riser_layer, "riser")
            QCoreApplication.processEvents()
            progressBar.setValue(25)
            dbox.append('-Slackloop-')
            validate_point_layer(slackloop_layer, "slackloop")
            QCoreApplication.processEvents()
            progressBar.setValue(25)
            #polygons
            dbox.append('-Project-')
            validate_polygon_layer(project_layer, "project")
            QCoreApplication.processEvents()
            progressBar.setValue(30)
            dbox.append('-Demarcarea-')
            validate_polygon_layer(demarcarea_layer, "demarcarea")
            QCoreApplication.processEvents()
            progressBar.setValue(35)
            dbox.append('-Permit-')
            validate_polygon_layer(permit_layer, "permit_polygons")
            QCoreApplication.processEvents()
            progressBar.setValue(35)
            
        #Overlaps & Stacked Features
        if any("Overlaps" in x for x in geom_checks):
            dbox.append(' \nChecking Overlaps\n ')
            validate_no_overlaps(path_layer, "path")
            QCoreApplication.processEvents()
            progressBar.setValue(55)
            validate_no_overlaps(conduit_layer, "conduit")
            QCoreApplication.processEvents()
            progressBar.setValue(55)
            validate_no_overlaps(strand_layer, "strand")
            QCoreApplication.processEvents()
            progressBar.setValue(55)
            validate_no_overlaps(pole_layer, "pole")
            QCoreApplication.processEvents()
            progressBar.setValue(65)
            validate_no_overlaps(structure_layer, "structure")
            QCoreApplication.processEvents()
            progressBar.setValue(75)
            #validate_no_overlaps(permit_layer, "permitarea")
            QCoreApplication.processEvents()
            progressBar.setValue(85)
            #validate_no_overlaps(site_layer, "address")
            QCoreApplication.processEvents()
            
        
    # 🔁 Run on all vector layers
    '''geom_checks = [
        geometriesListWidget.item(i).text()
        for i in range(geometriesListWidget.count())
        if geometriesListWidget.item(i).checkState() == Qt.Checked
    ]'''
    try:
        canvas.setRenderFlag(False) 
        if any("Invalid" in x for x in geom_checks):
            dbox.append("Checking for null/missing geometries in Engineering Layers...") 
            #Remove any existing "GeometryErrors" layers to remove clutter
            for layer in QgsProject.instance().mapLayers().values(): 
                if 'GeometryErrors' in layer.name():
                    QgsProject.instance().removeMapLayer(layer.id())
            #process Engineering Layers
            for layer in QgsProject.instance().mapLayers().values(): 
                if layer.type() == layer.VectorLayer and layer.name() in \
                    ['path', 'conduit', 'strand', 'fibercable', 'hutpoint', 'riser',
                    'slckloop','equipment', 'spliceclosure', 'pole', 'structure', 'address',
                    'project', 'demararea', 'permitarea']:
                    check_and_export_geometry_issues(layer)
        if any("Snapping" in x for x in geom_checks) or any("Fix" in x for x in geom_checks) or any("Overlaps" in x for x in geom_checks):
            dbox.append('Checking Snapping Errors...')
            feature_snapping_direction_overlaps(project_name)
        
        full_end_time = datetime.now()
        full_elapsed = full_end_time - full_start_time
        dbox.append(f"Whole program complete time in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
        print(f"Whole program check completed in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
        dbox.append(f'Finished at {datetime.now()}')
        progressBar.setValue(100)
    except Exception as e:
            dbox.append(errorFormat.format(str(e)))
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

    finally:
        canvas.setRenderFlag(True)    







