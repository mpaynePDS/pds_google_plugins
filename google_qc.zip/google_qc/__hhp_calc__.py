# -*- coding: utf-8 -*-
"""
Created on Monday, July 21, 2025
Vero QC LLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __hhp_calc__(bound, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat):

    try:
        dbox.append(f'HHP Calculation at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()

        #layers
        proj_lyr = project.mapLayersByName('project')[0]
        address_lyr = project.mapLayersByName('address')[0]
        workorderid = bound
        dbox.append(f'---{workorderid}---')
        #--------------------------------------
        try:
            expr = f'"workorderid" = \'{workorderid}\''
            bound = processing.run("native:extractbyexpression", {'INPUT':proj_lyr, 'EXPRESSION':expr,'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            progressBar.setValue(30)
            hhp = processing.run("native:extractbylocation", {'INPUT':address_lyr,'PREDICATE':[0],'INTERSECT':bound,'METHOD':0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            progressBar.setValue(60)
            expr_2 = f'"pds_delete_feature" is NULL'
            hhp_filtered = processing.run("native:extractbyexpression", {'INPUT':hhp, 'EXPRESSION':expr_2,'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            progressBar.setValue(90)
            dbox.append(f'Number of HHP = {str(hhp_filtered.featureCount())}')
            progressBar.setValue(100)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
    

                 

