# -*- coding: utf-8 -*-
"""
Created on Tues Oct 5, 2025
Google QC HLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from PyQt5.QtWidgets import QApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __main_HLD__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks, qcCheckButton, qcListWidget):
    try:
        dbox.append(f'HLD Started at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()
        existing_layer = QgsProject.instance().mapLayer('memory.gpkg')
        if existing_layer:
            QgsProject.instance().removeMapLayer(existing_layer)
        progressBar.setValue(1)
        # define AOI boundary + create output folder
        project_name = bound
        dbox.append(str(project_name)) 

        #--------------------
        qcChecks = [
            qcListWidget.item(i).text()
            for i in range(qcListWidget.count())
            if qcListWidget.item(i).checkState() == Qt.Checked
        ]
        proj_folder= f'{outputfolder}\\QC_{str(project_name)}'
        if not os.path.exists(proj_folder):
                os.mkdir(proj_folder)

        # Layers - Lines
        path_layer = QgsProject.instance().mapLayersByName("path")[0]
        #conduit_layer = QgsProject.instance().mapLayersByName("conduit")[0]
        #strand_layer = QgsProject.instance().mapLayersByName("strand")[0]
        fiber_layer = QgsProject.instance().mapLayersByName("fibercable")[0]
        # Layers = Points
        #hutpoint_layer = QgsProject.instance().mapLayersByName("hutpoint")[0]
        #riser_layer = QgsProject.instance().mapLayersByName("riser")[0]
        slackloop_layer = QgsProject.instance().mapLayersByName("slackloop")[0]
        #equipment_layer = QgsProject.instance().mapLayersByName("equipment")[0]
        spliceclosure_layer = QgsProject.instance().mapLayersByName("spliceclosure")[0]
        #pole_layer = QgsProject.instance().mapLayersByName("pole")[0]
        structure_layer = QgsProject.instance().mapLayersByName("structure")[0]
        #site_layer = QgsProject.instance().mapLayersByName("address")[0] #final address?
        # Layers - Polygons
        project_layer = QgsProject.instance().mapLayersByName("project")[0]
        demarcarea_layer = QgsProject.instance().mapLayersByName("demarcarea")[0]
        permit_layer = QgsProject.instance().mapLayersByName("permitarea")[0]
        property_layer = QgsProject.instance().mapLayersByName("property")[0]
        
        #--------------------------------------
        
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':project_layer, 'FIELD': 'workorderid', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        #selectedBound = processing.run("native:extractbyattribute", {'INPUT':project_layer,'FIELD':'workorderid','OPERATOR':0,'VALUE':project_name, 'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        workorderid = None
        for f in project_layer.selectedFeatures():
            if f['workorderid'] not in [None,'']:
                workorderid = f['workorderid']
            break
        if not workorderid:
            dbox.append(errorFormat.format('Missing Workorderid in Project layer.'))
        # Get F0 and F1 possible fda and segment id
        intersecting_bounds = processing.run("native:extractbylocation", {'INPUT':project_layer,'PREDICATE':[5],'INTERSECT':QgsProcessingFeatureSourceDefinition(project_layer.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        f0_dict = {}
        f1_dict = {}
        f1_f0_geoms = []
        for f in intersecting_bounds.getFeatures():
            if f['hierarchy'] in ['F0']:
                f0_dict[f['workorderid']] = [f['segment_name'], f.geometry(), f['name']]
                f1_f0_geoms.append(f.geometry())
            elif f['hierarchy'] in ['F1', 'BB']:
                f1_dict[f['workorderid']] = [f['segment_name'], f.geometry(), f['name']]
                f1_f0_geoms.append(f.geometry())
        #merged_f1f0 = QgsGeometry.unaryUnion(f1_f0_geoms)
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':project_layer, 'FIELD': 'workorderid', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}')) 
        return


    def _fibercable_():
        start_time = datetime.now()
        dbox.append('FIBERCABLE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':fiber_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            #fiber = processing.run("native:saveselectedfeatures", {'INPUT':fiber_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            errorDict = {
                    "Workorderid Invalid": 0,
                    "Status Invalid": 0,
                    "Category Invalid":0,
                    "Cablecapacity Invalid": 0,
                    "Core Invalid": 0,
                    "Fibercount Invalid":0,
                    "Buffercount Invalid":0,
                    "Buffercount CalculationMismatch":0,
                    "FibersPerBuffer Invalid": 0,
                    "FibersPerBuffer CoreMismatch":0,
                    "AssignedFibers Invalid":0,
                    "Placement Invalid":0,
                    "Hierarchy Invalid":0,
                    "Cablename Invalid":0,
                    "Invalid Leg":0,
                    "Cablename\Leg Mismatch":0
                    
                }
            total = fiber_layer.selectedFeatureCount()
            if fiber_layer.isEditable():
                fiber_layer.commitChanges()
            with edit(fiber_layer):
                for idx, f in enumerate(fiber_layer.selectedFeatures(), 1):
                    f_errors = []
                    if f['workorderid'] in [None, '']:
                        errorDict['Workorderid Invalid'] += 1
                        f_errors.append('Workorderid_Invalid')
                    if f['status'] in [None, ''] or f['status'] not in ['ABAN', 'FDA', 'PL', 'Planned', 'Abandoned']:
                        errorDict['Status Invalid'] += 1
                        f_errors.append('Status_Invalid')
                    if f['category'] in [None, ''] or f['category'] not in ['BB', 'DF', 'TIER2', 'AF','DROP']:
                        errorDict['Category Invalid'] += 1
                        f_errors.append('Category_Invalid')
                    if f['cablecapacity'] in [None, ''] or f['cablecapacity'] not in ['2', '24', '96', '144', '288', '432']:
                        errorDict['Cablecapacity Invalid'] += 1
                        f_errors.append('Cablecapacity_Invalid')
                        capacity = False
                    else:
                        capacity = True
                    if f['core'] in [None, ''] or f['core'] not in ['LOOSE', 'RIBBON']:
                        errorDict['Core Invalid'] += 1
                        f_errors.append('Core_Invalid')
                        core = False
                    else:
                        core = True
                    if f['fibercount'] in [None, ''] or f['fibercount'] not in [2, 24, 96, 144, 288, 432]:
                        errorDict['Fibercount Invalid'] += 1
                        f_errors.append('Fibercount_Invalid')
                    if f['fibersperbuffer'] in [None, ''] or f['fibersperbuffer'] not in [12, 24]:
                        errorDict['FibersPerBuffer Invalid'] +=1
                        f_errors.append('FibersPerBuffer_Invalid')
                    elif core:
                        if (f['core'] == 'LOOSE' and f['fibersperbuffer'] != 12) or (f['core'] == 'RIBBON' and f['fibersperbuffer'] != 24):
                            errorDict['FibersPerBuffer CoreMismatch'] +=1
                            f_errors.append('FibersPerBuffer_CoreMismatch')
                    if f['buffercount'] in [None, ''] or f['buffercount'] not in [2, 8, 12, 24, 36, 72]:
                        errorDict['Buffercount Invalid'] += 1
                        f_errors.append('Buffercount_Invalid')
                    elif capacity and core:
                        buffercount = int(f['cablecapacity'])/int(f['fibersperbuffer'])
                        if f['buffercount'] != buffercount:
                            errorDict['Buffercount CalculationMismatch'] +=1
                            f_errors.append('Buffercount_CalculationMismatch')
                   
                    if f['assignedfibers'] in [None, ''] and f['category'] == 'AF': #only AF requires assigned fibers at 60% (Lester Manolo Jan 6, 2026)
                        errorDict['AssignedFibers Invalid'] +=1
                        f_errors.append('AssignedFibers_Invalid')
                    if f['cablename'] in [None, '']:
                        errorDict['Cablename Invalid'] +=1
                        f_errors.append('Cablename_Invalid')
                        cablename = False
                    else:
                        cablename = True
                    if f['leg'] in [None, '']:
                        errorDict['Invalid Leg'] += 1
                        f_errors.append('Invalid_Leg')
                    elif cablename and f['leg'] != f['cablename'][-1] or not cablename:
                        errorDict['Cablename\Leg Mismatch'] +=1
                        f_errors.append('Cablename\Leg_Mismatch')
                    #Placement , just AE/UG
                    if f['placement'] in [None, ''] or f['placement'] not in ['PLACEMENT_AERIAL', 'PLACEMENT_UNDERGROUND']:
                        errorDict['Placement Invalid'] +=1
                        f_errors.append('Placement_Invalid')
                   
                    if f['hierarchy'] in [None, ''] or f['hierarchy'] not in ['BB', 'DF', 'TIER2', 'AF', 'DROP']:
                        errorDict['Hierarchy Invalid'] +=1
                        f_errors.append('Hierarchy_Invalid')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    fiber_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)

        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Fibercable check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")

    def _spliceclosure_():
        start_time = datetime.now()
        dbox.append('SPLICE CLOSURE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':spliceclosure_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            #fiber = processing.run("native:saveselectedfeatures", {'INPUT':fiber_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            errorDict = {
                    "Workorderid Invalid": 0,
                    "Status Invalid": 0,
                    "Hierarchy Invalid": 0,
                    "ClosureUse Invalid": 0,
                    "ClosureSize Invalid": 0,
                    "SpliceType Invalid": 0,
                    "SpliceType UseMismatch":0,
                    "SplicePlacement Invalid":0,
                    "Invalid Spliceid":0,
                    "Name Invalid":0
                    
                }
            total = spliceclosure_layer.selectedFeatureCount()
            if spliceclosure_layer.isEditable():
                spliceclosure_layer.commitChanges()
            with edit(spliceclosure_layer):
                for idx, f in enumerate(spliceclosure_layer.selectedFeatures(), 1):
                    f_errors = []
                    if f['workorderid'] in [None, '']:
                        errorDict['Workorderid Invalid'] += 1
                        f_errors.append('Workorderid_Invalid')
                    if f['status'] in [None, ''] or f['status'] not in ['FDA', 'PL', 'Planned', 'AB', 'AsBuit']:
                        errorDict['Status Invalid'] += 1
                        f_errors.append('Status_Invalid')

                    #Hiearchy - document says "drop", but that's not a dropdown option, is that F4?
                    if f['hierarchy'] in [None, ''] or f['hierarchy'] not in ['BB', 'DF', 'TIER2', 'AF']:
                        errorDict['Hierarchy Invalid'] +=1
                        f_errors.append('Hierarchy_Invalid')
                    if f['closureuse'] in [None, ''] or f['closureuse'] not in ['RE', 'MCA', 'DROP']:
                        errorDict['ClosurUse Invalid'] +=1
                        f_errors.append('ClosureUse_Invalid')
                        closureuse = False
                    else:
                        closureuse = True
                    if f['closuresize'] in [None, ''] or f['closuresize'] not in ['DROP', 'DTC-8', 'B', 'D', '600']:
                        errorDict['ClosureSize Invalid'] += 1
                        f_errors.append('ClosureSize_Invalid')
                    
                    if f['splicetype'] in [None, ''] or f['splicetype'] not in ['SINGLE', '7']: # 7 = Butt
                        errorDict['SpliceType Invalid'] += 1
                        f_errors.append('SpliceType_Invalid')
                    elif closureuse:
                        #Butt only to be used RE, all RE or just some?
                        if f['splicetype'] in ['7'] and f['closureuse'] not in ['RE']:
                            errorDict['SpliceType UseMismatch'] += 1
                            f_errors.append('SpliceType UseMismatch')
                    if f['spliceplacement'] in [None, ''] or f['spliceplacement'] not in ['PLACEMENT_AERIAL', 'PLACEMENT_UNDERGROUND', 'PLACEMENT_DIRECT_BURY']:
                        errorDict['SplicePlacement Invalid'] += 1
                        f_errors.append('SplicePlacement_Invalid')
                    if f['spliceid'] in [None, '']:
                        errorDict['Invalid Spliceid'] +=1
                        f_errors.append('Invalid_Spliceid')   
                    if f['name'] in [None, ''] or f['name'] != f['spliceid']:
                        errorDict['Name Invalid'] +=1
                        f_errors.append('Name_Invalid')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    spliceclosure_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Spliceclosure check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
                     
    def _structure_():
        start_time = datetime.now()
        dbox.append('STRUCTURE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':structure_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            #fiber = processing.run("native:saveselectedfeatures", {'INPUT':fiber_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            errorDict = {
                    "Workorderid Invalid": 0,
                    "Hierarchy Invalid":0,
                    "Vaultsize Invalid":0,
                    "Rating Invalid": 0,
                    "Structureform Invalid":0,
                    "Stub_Out Invalid":0,
                    "Invalid LidMaterial":0,
                    "LidMaterial\Rating Mismatch":0
                    
                }
            total = structure_layer.selectedFeatureCount()
            if structure_layer.isEditable():
                structure_layer.commitChanges()
            with edit(structure_layer):
                for idx, f in enumerate(structure_layer.selectedFeatures(), 1):
                    f_errors = []
                    if f['workorderid'] in [None, '']:
                        errorDict['Workorderid Invalid'] += 1
                        f_errors.append('Workorderid_Invalid')
                    #Hiearchy - document says "drop", but that's not a dropdown option, is that F4?
                    if f['hierarchy'] in [None, ''] or f['hierarchy'] not in ['BB', 'DF', 'TIER2', 'AF']:
                        errorDict['Hierarchy Invalid'] +=1
                        f_errors.append('Hierarchy_Invalid')
                    if f['vaultsize'] in [None, '']:
                        errorDict['Vaultsize Invalid'] +=1
                        f_errors.append('Vaultsize_Invalid')
                    rating = False
                    if f['rating'] in [None, ''] or f['rating'] not in ['H20', 'LightDuty', 'Tier15', 'Tier22', 'Tier08', 'Tier05']:
                        errorDict['Rating Invalid'] += 1
                        f_errors.append('Rating_Invalid')
                    else:
                        rating = True
                    if f['lidmaterial'] in [None, ''] or f['lidmaterial'] not in ['Plastic_Material', 'Polymer_Concrete']:
                        errorDict['Invalid LidMaterial'] +=1
                        f_errors.append('Invalid_LidMaterial')
                    elif rating:
                        if  (f['rating'] == 'Tier05' and f['lidmaterial'] != 'Plastic_Material') or \
                            (f['rating'] in ['Tier15', 'Tier22'] and f['lidmaterial'] != 'Polymer_Concrete'):
                            errorDict['LidMaterial\Rating Mismatch'] += 1
                            f_errors.append('LidMaterial\Rating_Mismatch')
            
                    if f['structureform'] in [None, ''] or f['structureform'] not in ['Directbury', 'Handhole', 'Manhole', 'Other', 'Pedestal', 'Vault']:
                        errorDict['Structureform Invalid'] +=1
                        f_errors.append('Structureform_Invalid')
                    if f['stub_out'] in [None, ''] or f['stub_out'] not in ['Yes', 'No']:
                        errorDict['Stub_Out Invalid'] += 1
                        f_errors.append('Stub_out_Invalid')
                    
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    structure_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Structure check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    def _property_():
        start_time = datetime.now()
        dbox.append('PROPERTY BOUNDARY CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':property_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            #fiber = processing.run("native:saveselectedfeatures", {'INPUT':fiber_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            errorDict = {  
                        'Invalid PropertyId': 0,
                        'Invalid Relatedaddress':0,
                        'Invalid PropertyDisqualReason':0,
                        'Invalid UnitCount':0,
                        'Invalid PropertyType':0
                }
            total = property_layer.selectedFeatureCount()
            if property_layer.isEditable():
                property_layer.commitChanges()
            with edit(property_layer):
                for idx, f in enumerate(property_layer.selectedFeatures(), 1):
                    f_errors = []
                    #if f['propertyid'] in [None, '']:
                    #    errorDict['Invalid PropertyID'] += 1
                    #    f_errors.append('Invalid_PropertyId')
                    if not f['relatedaddress'] or f['relatedaddress'] in [None, '']:
                        errorDict['Invalid Relatedaddress'] +=1
                        f_errors.append('Invalid_Relatedaddress')
                    if not f['propertydisqualreason'] or f['propertydisqualreason'] in [None, ''] or f['propertydisqualreason'] not in ['PENDING_CONSTRUCTION']:
                        errorDict['Invalid PropertyDisqualReason'] +=1
                        f_errors.append('Invalid_PropertyDisqualReason')
                    if not f['unitcount'] or not isinstance(f['unitcount'], int):
                        errorDict['Invalid UnitCount'] += 1
                        f_errors.append('Invalid_UnitCount')
                    if not f['propertytype'] or f['propertytype'] in [None, ''] or f['propertytype'] not in ['MXU_DEVELOPMENT', 'SXU_ROE']:
                        errorDict['Invalid PropertyType'] += 1
                        f_errors.append('Invalid_PropertyType')
                    
                    
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    property_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Property Boundary check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    def _demarc_():
        start_time = datetime.now()
        dbox.append('DEMARC AREA CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':demarcarea_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            errorDict = {  
                'Invalid Status': 0,
                'Invalid DemarcType':0,
                'Invalid Hierarchy':0,
                'Invalid Workorderid':0,
                'Invalid HHP Count':0,
                'Demarctype/Hierarchy Mismatch':0
                }
            total = demarcarea_layer.selectedFeatureCount()
            if demarcarea_layer.isEditable():
                demarcarea_layer.commitChanges()
            with edit(demarcarea_layer):
                for idx, f in enumerate(demarcarea_layer.selectedFeatures(), 1):
                    f_errors = []
                    if f['status'] in [None, ''] or f['status'] not in ['FDA', 'Planned', 'PL', 'ABAN']:
                        errorDict['Invalid Status'] += 1
                        f_errors.append('Invalid_Status')
                    if f['demarctype'] in [None, ''] or f['demarctype'] not in ['MSL', 'LCP']:
                        errorDict['Invalid DemarcType'] += 1
                        f_errors.append('Invalid_DemarcType')
                    if f['hierarchy'] in [None, ''] or f['hierarchy'] not in ['Tier2', 'DF']:
                        errorDict['Invalid Hierarchy'] +=1
                        f_errors.append('Invalid_Hierarchy')
                    if f['demarctype'] is not None:
                        if f['demarctype'] == 'MSL' and f['hierarchy'] != 'Tier2' or\
                            f['demarctype'] == 'LCP' and f['hierarchy'] != 'DF':
                            errorDict['Demarctype/Hierarchy Mismatch'] +=1
                            f_errors.append('Demarctype/Hierarchy_Mismatch')
                    if f['workorderid'] in [None, '']:
                        errorDict['Invalid Workorderid'] +=1
                        f_errors.append('Invalid_Workorderid')
                    if f['hhp_count'] in [None, ''] or not isinstance(f['hhp_count'], int):
                        errorDict['Invalid HHP Count']+=1
                        f_errors.append('Invalid_HHP_Count')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    demarcarea_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Demarc Area check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")                      

    def _project_():
        start_time = datetime.now()
        dbox.append('PROJECT BOUNDARY CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':project_layer, 'FIELD': 'workorderid', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']

            #processing.run("native:selectbylocation", {'INPUT':project_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            #fiber = processing.run("native:saveselectedfeatures", {'INPUT':fiber_layer,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            errorDict = {  
                'Invalid Status': 0,
                'Name Invalid': 0,
                'Invalid ProjectType':0,
                'Invalid ProjectStatus':0,
                'Invalid DateApproved':0,
                'Invalid FundedYear':0,
                'Invalid Hierarchy':0,
                'Invalid Workorderid':0,
                'Invalid HHP Count':0
                }
            total = project_layer.selectedFeatureCount()
            if project_layer.isEditable():
                project_layer.commitChanges()
            with edit(project_layer):
                for idx, f in enumerate(project_layer.selectedFeatures(), 1):
                    f_errors = []
                    if not f['status'] or f['status'] in [None, ''] or f['status'] not in ['FDA', 'PL', 'Planned', 'ABAN']:
                        errorDict['Invalid Status'] +=1
                        f_errors.append('Invalid_Status')
                    if not f['name'] or f['name'] in [None, ''] or f['name'] != workorderid:
                        errorDict['Name Invalid'] += 1
                        f_errors.append('Name_Invalid')
                    if f['projecttype'] in [None, ''] or f['projecttype'] not in ['PLANNING_SEGMENT']:
                        errorDict['Invalid ProjectType'] +=1
                        f_errors.append('Invalid_ProjectType')
                    if f['projectstatus'] in [None, ''] or f['projectstatus'] not in ['APPROVED_AND_FUNDED']:
                        errorDict['Invalid ProjectStatus'] += 1
                        f_errors.append('Invalid_ProjectStatus')
                    if f['dateapproved'] in [None, '']:
                        errorDict['Invalid DateApproved'] += 1
                        f_errors.append('Invalid_DateApproved')
                    if f['fundedyear'] in [None, '']:
                        errorDict['Invalid FundedYear'] +=1
                        f_errors.append('Invalid_FundedYear')
                    if f['hierarchy'] in [None, ''] or f['hierarchy'] not in ['BB', 'DF', 'TIER2', 'AF', 'DROP']:
                        errorDict['Invalid Hierarchy'] +=1
                        f_errors.append('Inavlid_Hierarchy')
                    if f['workorderid'] in [None, ''] :
                        errorDict['Invalid Workorderid'] +=1
                        f_errors.append('Invalid_Workorderid')
                    if f['hhp_count'] in [None, ''] or not isinstance(f['hhp_count'], int):
                        errorDict['Invalid HHP Count'] += 1
                        f_errors.append('Invalid_HHP_Count')
                    
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    project_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Project Boundary check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
                    
    def _slackloop_():
        start_time = datetime.now()
        dbox.append('SLACK LOOP CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':slackloop_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})

            errorDict = {  
                'Invalid Status': 0,
                'Invalid Workorderid':0,
                'Invalid MeasuredLength':0,
                'Invalid Cablecapacity':0
                }
            total = slackloop_layer.selectedFeatureCount()
            if slackloop_layer.isEditable():
                slackloop_layer.commitChanges()
            with edit(slackloop_layer):
                for idx, f in enumerate(slackloop_layer.selectedFeatures(), 1):
                    f_errors = []
                    if f['status'] in [None, ''] or f['status'] not in ['FDA', 'Planned', 'PL', 'ABAN']:
                        errorDict['Invalid Status'] += 1
                        f_errors.append('Invalid_Status')
                    if f['workorderid'] in [None, '']:#f['hierarchy'] != workorderid
                        errorDict['Invalid Workorderid'] +=1
                        f_errors.append('Invalid_Workorderid')
                    if f['measuredlength'] in [None, ''] or int(f['measuredlength']) not in [25, 40, 100, 150]: #Added 40ft 1/6/2025 email @lester manolo
                        errorDict['Invalid MeasuredLength'] +=1
                        f_errors.append('Invalid_MeasuredLength')
                    if f['cablecapacity'] in [None, ''] or int(f['cablecapacity']) not in [2,24,96,144,288,432]:
                        errorDict['Invalid Cablecapacity'] +=1
                        f_errors.append('Inalid_Cablecapacity')

                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    slackloop_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Slack Loop check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")                      

    def _path_():
        start_time = datetime.now()
        dbox.append('PATH CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':path_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})

            errorDict = {  
                'Invalid Status': 0,
                'Invalid Hierarchy':0,
                'Invalid Workorderid':0,
                'Invalid Placement': 0,
                'Invalid Name': 0,
                'Invalid InstallMethod':0,
                'Invalid SurfaceType': 0,
                'InstallMethod/SurfaceType_Mismatch':0,
                'Invalid Tonewire':0,
                'Invalid P6id':0
                }
            total = path_layer.selectedFeatureCount()
            if path_layer.isEditable():
                path_layer.commitChanges()
            with edit(path_layer):
                for idx, f in enumerate(path_layer.selectedFeatures(), 1):
                    f_errors = []
                    if f['status'] in [None, ''] or f['status'] not in ['FDA', 'Planned', 'PL']:
                        errorDict['Invalid Status'] += 1
                        f_errors.append('Invalid_Status')
                    if f['hierarchy'] in [None, ''] or f['hierarchy'] not in ['TIER2', 'DF', 'AF', 'DROP', 'BB']:
                        errorDict['Invalid Hierarchy'] +=1
                        f_errors.append('Invalid_Hierarchy')
                    if f['workorderid'] in [None, ''] or f['workorderid'] != workorderid:
                        errorDict['Invalid Workorderid'] +=1
                        f_errors.append('Invalid_Workorderid')
                    if f['placement'] in [None, ''] or f['placement'] not in ['PLACEMENT_DIRECT_BURY', 'PLACEMENT_MIXEDTRENCH', 'PLACEMENT_UNDERGROUND', 'PLACEMENT_AERIAL']:
                        errorDict['Invalid Placement'] += 1
                        f_errors.append('Invalid_Placement')
                    if f['name'] in [None, '']:
                        errorDict['Invalid Name'] += 1
                        f_errors.append('Invalid_Name')
                    install_method = False
                    if f['installmethod'] in [None, ''] or f['installmethod'] not in ['ShallowTrenchHardscape', 'ShallowTrenchSoftscape', 'Trench', 'Bore', 'Aerial']:
                        errorDict['Invalid InstallMethod'] +=1
                        f_errors.append('Invalid_InstallMethod')
                    else:
                        install_method = True
                    if f['surfacetype'] in [''] or f['surfacetype'] not in ['Asphalt', 'Concrete', 'Soft', None]:
                        errorDict['Invalid SurfaceType'] += 1
                        f_errors.append('Invalid_SurfaceType')
                    elif install_method:
                        if  (f['installmethod'] in ['Bore', 'Aerial'] and f['surfacetype'] is not None) or \
                            (f['installmethod'] == 'ShallowTrenchHardscape' and f['surfacetype'] not in ['Asphalt', 'Concrete']) or \
                            (f['installmethod'] == 'ShallowTrenchSoftscape' and f['surfacetype'] not in ['Soft']):
                            errorDict['InstallMethod/SurfaceType_Mismatch'] += 1
                            f_errors.append('InstallMethod/SurfaceType_Mismatch')
                    if f['tonewire'] in [None, ''] or f['tonewire'] not in ['Y', 'N']:
                        errorDict['Invalid Tonewire'] +=1
                        f_errors.append('Invalid_Tonewire')
                    if f['p6id'] in [None, ''] or f['p6id'] not in ['8"', '12"', '36"', '48"', '60"']:
                        errorDict['Invalid P6id'] +=1
                        f_errors.append('Invalid_P6id')
                                            
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    path_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Path check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")                      

    def _permit_():
        start_time = datetime.now()
        dbox.append('PERMIT AREA CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':permit_layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})

            errorDict = {  
                'Invalid Name':0,
                'Invalid PermitType':0,
                'Invalid Print':0,
                'Invalid P6id':0
                }
            total = permit_layer.selectedFeatureCount()
            if permit_layer.isEditable():
                permit_layer.commitChanges()
            with edit(permit_layer):
                for idx, f in enumerate(permit_layer.selectedFeatures(), 1):
                    f_errors = []
                    if f['name'] in [None, '']:
                        errorDict['Invalid Name'] +=1
                        f_errors.append('Invalid_Name')
                    if f['permittype'] in [None, ''] or f['permittype'] not in ['CITY', 'DOT', 'OTHER', 'RR']:
                        errorDict['Invalid PermitType'] +=1
                        f_errors.append('Invalid_PermitType')
                    #if f['citypermitdescription'] in [None, '']
                    if f['p6id'] in [None, '']:
                        errorDict['Invalid P6id'] +=1
                        f_errors.append('Invalid_P6id')
                    if f['print'] in [None, ''] or f['print'] not in ['Y', 'N']:
                        errorDict['Invalid Print'] +=1
                        f_errors.append('Invalid_Print')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    permit_layer.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Permit Area check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")                      

    if len(geom_checks)>0:
        __invalid_geoms__(bound, dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks)
    else:
        print('geometry check box not checked')
    progressBar.setValue(12)
    if qcCheckButton:
        progressBar.setValue(25)
        if "project" in qcChecks:
            _project_()
            QApplication.processEvents()
            progressBar.setValue(int(25+(1/9*100)))
        if "structure" in qcChecks:
            _structure_()   
            QApplication.processEvents()
            progressBar.setValue(int(25+(2/9*100)))
        if "property" in qcChecks:
            _property_()
            QApplication.processEvents() 
            progressBar.setValue(int(25+(3/9*100)))
        if "permitarea" in qcChecks:
            _permit_()
            QApplication.processEvents()
            progressBar.setValue(int(25+(4/9*100)))
        if "path" in qcChecks:
            _path_()
            QApplication.processEvents()
            progressBar.setValue(int(25+(5/9*100)))
        if "fibercable" in qcChecks:
            _fibercable_()
            QApplication.processEvents()
            progressBar.setValue(int(25+(6/9*100)))
        if "spliceclosure" in qcChecks:
            _spliceclosure_()
            QApplication.processEvents()
            progressBar.setValue(int(25+(7/9*100)))
        if "demarcarea" in qcChecks:
            _demarc_()
            QApplication.processEvents()
            progressBar.setValue(int(25+(8/9*100)))
        if "slackloop" in qcChecks:
            _slackloop_()
            QApplication.processEvents()
            progressBar.setValue(int(25+(9/9*100)))
        
      
        dbox.append(f'QC Plugin Complete \u2713')
    full_end_time = datetime.now()
    full_elapsed = full_end_time - full_start_time
    dbox.append(f"Whole program complete time in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
    print(f"Whole program check completed in {full_elapsed.seconds // 60} min {full_elapsed.seconds % 60} sec")
    dbox.append(f'Finished at {datetime.now()}')
    progressBar.setValue(100)

