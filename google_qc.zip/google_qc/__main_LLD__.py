# -*- coding: utf-8 -*-
"""
Created on Monday, July 21, 2025
Vero QC LLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __main_LLD__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geom_checks, qcCheckButton, qcListWidget):
    try:
        dbox.append(f'LLD Started at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()
        existing_layer = QgsProject.instance().mapLayer('memory.gpkg')
        if existing_layer:
            QgsProject.instance().removeMapLayer(existing_layer)
        progressBar.setValue(1)
        #--------------------
        qcChecks = [
            qcListWidget.item(i).text()
            for i in range(qcListWidget.count())
            if qcListWidget.item(i).checkState() == Qt.Checked
        ]
        # define AOI boundary + create output folder
        project_name = bound
        dbox.append(str(project_name))
        proj_folder= f'{outputfolder}\\QC_{str(project_name)}'
        if not os.path.exists(proj_folder):
                os.mkdir(proj_folder)
        #layers
        fda_boundary = project.mapLayersByName('Cabinet_Boundary')[0]
        access_pts = project.mapLayersByName('Access_Point')[0]
        fibercables = project.mapLayersByName('Fiber_Cable')[0]
        nap_boundary = project.mapLayersByName('NAP_Boundary')[0]
        network_elements = project.mapLayersByName('Network_Element')[0]
        poles = project.mapLayersByName('Pole')[0]
        segments = project.mapLayersByName('Segments')[0]
        sites = project.mapLayersByName('Site')[0]
        splicings = project.mapLayersByName('Splicing')[0]
        
        #--------------------------------------
        
        #bound = processing.run("native:extractbyexpression", {'INPUT':fda_boundary, 'EXPRESSION': f'"area_id" LIKE \'%{project_name}%\'','OUTPUT': f'{proj_folder}\\bound.gpkg'})['OUTPUT']
        selectedBound = processing.run("qgis:selectbyattribute", {'INPUT':fda_boundary, 'FIELD': 'area_id', 'OPERATOR': 0, 'VALUE': project_name, 'METHOD': 0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
        fda_name = None
        segment_id = None
        area_id = None
        wire_center = None
        for f in fda_boundary.selectedFeatures():
            if f['fda_name'] not in [None,'']:
                fda_name = f['fda_name']
            if f['segment_id'] not in [None, ''] and '-' in f['segment_id']:
                segment_id = f['segment_id']
            if f['area_id'] not in [None, '']:
                area_id = f['area_id']
            if f['wire_center'] not in [None, '']:
                wire_center = f['wire_center']
            break
        # Get F0 and F1 possible fda and segment id
        intersecting_bounds = processing.run("native:extractbylocation", {'INPUT':fda_boundary,'PREDICATE':[5],'INTERSECT':QgsProcessingFeatureSourceDefinition(fda_boundary.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        f0_dict = {}
        f1_dict = {}
        f1_f0_geoms = []
        for f in intersecting_bounds.getFeatures():
            if 'F0' in f['fda_name']:
                f0_dict[f['area_id']] = [f['segment_id'], f.geometry(), f['fda_name']]
                f1_f0_geoms.append(f.geometry())
            elif 'F1' in f['fda_name']:
                f1_dict[f['area_id']] = [f['segment_id'], f.geometry(), f['fda_name']]
                f1_f0_geoms.append(f.geometry())
        merged_f1f0 = QgsGeometry.unaryUnion(f1_f0_geoms)

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}')) 
        return
    def cabinet():
        start_time = datetime.now()
        dbox.append('CABINET BOUNDARY CHECKS')
        dbox.append('____________________________________________________________________________________________')
        #
        sitesWithinBound = processing.run("native:selectbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        count_sitesWithinBound = sites.selectedFeatureCount()
        try:
            errorDict = {
                "Segment ID Invalid": 0,
                "Wire Center Invalid": 0,
                "Wire Center Mismatch": 0,
                "FDA Name Invalid": 0,
                "FDA Name/Zone Mismatch": 0,
                "Hub Size Invalid": 0,
                "Estimated HHP Invalid":0,
                "Estimated HHP Mismatch":0
            }
            total = fda_boundary.selectedFeatureCount()
            if fda_boundary.isEditable():
                fda_boundary.commitChanges()
            with edit(fda_boundary):
                for idx, f in enumerate(fda_boundary.selectedFeatures(), 1):
                    f_errors = []
                    #
                    if f['segment_id'] in [None, ''] or '-' not in f['segment_id']:
                        if all(x not in f['fda_name'] for x in ['F0', 'F1']): #F0 and F1 will not not have segment ID
                            errorDict['Segment ID Invalid'] += 1
                            f_errors.append('Segment_ID_Invalid')
                    elif '-' in f['segment_id']: #F2 Zones
                        wirecenter = f['segment_id'].split('-')[0]
                        fda_name = f['segment_id'].split('-')[-1]
                        if f['wire_center'] in [None, '']:
                            errorDict['Wire Center Invalid'] += 1
                            f_errors.append('Wire_Center_Invalid')
                        '''elif f['wire_center'] != wirecenter:
                            errorDict['Wire Center Mismatch'] += 1     
                            f_errors.append('Wire_Center_Mismatch') '''
                        if f['fda_name'] in [None, '']:
                            errorDict['FDA Name Invalid'] += 1
                            f_errors.append('FDA_Name_Invalid')
                        '''elif f['fda_name'] != fda_name:
                            errorDict['FDA Name/Zone Mismatch'] += 1
                            f_errors.append('FDA_Name/Zone_Mismatch')'''#Not possible
                    if f['hub_size'] in [None,'']:
                        errorDict['Hub Size Invalid'] += 1
                        f_errors.append('Hub_Size_Invalid')
                    if f['estimated_hhp'] in [None, ''] or not isinstance(int(f['estimated_hhp']), int):
                        errorDict['Estimated HHP Invalid'] += 1
                        f_errors.append('Estimated_HHP_Invalid')
                    elif int(f['estimated_hhp']) != count_sitesWithinBound:
                        errorDict['Estimated HHP Mismatch'] += 1
                        f_errors.append('Estimated_HHP_Mismatch')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    fda_boundary.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Cabinet boundary check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")


    def access_points():
        start_time = datetime.now()
        dbox.append('ACCESS POINTS CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:
            processing.run("native:selectbylocation", {'INPUT':access_pts,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            processing.run("native:selectbylocation", {'INPUT':fibercables,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            
            
            access_extract = processing.run("native:saveselectedfeatures", {'INPUT':access_pts,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            access_spl = processing.run("native:joinattributesbylocation", {'INPUT':access_extract,'PREDICATE':[0],'JOIN': splicings,'JOIN_FIELDS':['tags','type', 'material'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'s_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            access_spl_ele =  processing.run("native:joinattributesbylocation", {'INPUT':access_spl,'PREDICATE':[0],'JOIN': network_elements,'JOIN_FIELDS':['element_type'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'ne_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #access_spl_ele_fc =  processing.run("native:joinattributesbylocation", {'INPUT':access_spl_ele,'PREDICATE':[0],'JOIN': QgsProcessingFeatureSourceDefinition(fibercables.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'JOIN_FIELDS':['fibercount'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'','OUTPUT': 'memory:joined_access_pts'})['OUTPUT']
            # ------------add all associated cable sizes to access_point
            # Build spatial index for access_spl_ele points
            structure_index = QgsSpatialIndex(access_spl_ele.getFeatures())
            # Distance calculator
            distance_calc = QgsDistanceArea()
            distance_calc.setSourceCrs(fibercables.crs(), QgsProject.instance().transformContext())
            distance_calc.setEllipsoid('WGS84')  # Optional
            # Set tolerance (1 foot)
            tolerance = 1.0  # If CRS is in feet; use 0.3048 if in meters
            # Prepare mapping: access_spl_ele ID -> set of fibercounts
            structure_cable_map = {}
            fibercount_domain = {
                1: 2,
                2: 4,
                3: 6,
                4: 8,
                5: 12,
                6: 24,
                7: 48,
                8: 96,
                9: 144,
                10: 288,
                11: 432,
                12: 864
            }
            # Iterate over cable features
            for cable_feat in fibercables.getFeatures():
                geom = cable_feat.geometry()
                if geom is None or geom.isEmpty():
                    continue  # Skip features with no geometry
                fibercount = fibercount_domain[cable_feat["fibercount"]] if cable_feat["fibercount"] not in [None, ''] else None
                # Get start and end points
                if geom.isMultipart():
                    line = geom.asMultiPolyline()[0]
                else:
                    line = geom.asPolyline()
                if not line:
                    continue
                endpoints = [QgsPointXY(line[0]), QgsPointXY(line[-1])]
                for pt in endpoints:
                    pt_geom = QgsGeometry.fromPointXY(pt)
                    nearby_ids = structure_index.intersects(pt_geom.boundingBox())

                    for sid in nearby_ids:
                        structure_feat = access_spl_ele.getFeature(sid)
                        struct_geom = structure_feat.geometry()

                        # Check exact intersection or within tolerance
                        if struct_geom.intersects(pt_geom) or distance_calc.measureLine(pt, struct_geom.asPoint()) <= tolerance:
                            if sid not in structure_cable_map:
                                structure_cable_map[sid] = set()
                            structure_cable_map[sid].add(fibercount)

            # Add new field to access_spl_ele layer called "fibercounts" which lists all fiber sizes connected to point. Max fiber size dictates Access Pt size.
            access_spl_ele.startEditing()
            if "fibercounts" not in [f.name() for f in access_spl_ele.fields()]:
                access_spl_ele.dataProvider().addAttributes([QgsField("fibercounts", QVariant.String)])
                access_spl_ele.updateFields()

            # Write fibercounts to access_spl_ele features
            for sid, counts in structure_cable_map.items():
                access_spl_ele.changeAttributeValue(sid, access_spl_ele.fields().indexFromName("fibercounts"), ",".join(map(str, sorted(counts))))

            access_spl_ele.commitChanges()
            #
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))
        #Perform attribute join in-situ
        QgsProject.instance().addMapLayer(access_spl_ele)
        try:
            jlayer = project.mapLayersByName(access_spl_ele.name())[0]
            joinObject = QgsVectorLayerJoinInfo()
            joinObject.setJoinFieldName('uuid')
            joinObject.setTargetFieldName('uuid')
            joinObject.setJoinLayerId = jlayer.id()
            joinObject.setJoinLayer(jlayer)
            joinObject.setPrefix('j_')
            joinObject.setUsingMemoryCache(True)
            access_pts.addJoin(joinObject)
        
            #
            errorDict = {
                "FDA Name Mismatch": 0,
                "Wrong Status": 0,
                "Wrong Physical Status": 0,
                "Comments Invalid": 0,
                "Size/Fibercount Mismatch":0,
                "Size/Splice Mismatch": 0,
                "Hierarchy Invalid": 0,
                "Hierarchy/Geom Mismatch":0,
                "Segment ID Invalid":0,
                "Group Invalid": 0,
                "Type Mismatch": 0
            }
            total = access_pts.selectedFeatureCount()
            if access_pts.isEditable():
                access_pts.commitChanges()
            with edit(access_pts):
                for idx, f in enumerate(access_pts.selectedFeatures(), 1):
                    f_errors = []
                    # Hierarchy 1: F1, 2: F2, 3: F1/F2, 4: F0, 5: F0/F1, 6: F0/F2, 7: F0/F1/F2
                    if f['hierarchy'] in [None, '']:
                        errorDict['Hierarchy Invalid'] += 1
                        f_errors.append('Hierarchy_Invalid')
                    else:
                        geom = f.geometry()
                        if f['hierarchy'] in [4,5,6,7]: #contains F0
                            f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                            f0_fda_name = next((f0_dict[x][2] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                            if f0_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if f['segment_id'] in [None, ''] or f['segment_id'] != f0_segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                                if f['group'] in [None, ''] or f['group'] != f0_fda_name:
                                    errorDict['Group Invalid'] += 1
                                    f_errors.append('Group_Invalid')
                        elif f['hierarchy'] in [1,3]: #contains F1:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            f1_fda_name = next((f1_dict[x][2] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if f['segment_id'] in [None, ''] or f['segment_id'] != f1_segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                                if f['group'] in [None, ''] or f['group'] != f1_fda_name:
                                    errorDict['Group Invalid'] += 1
                                    f_errors.append('Group_Invalid')
                        elif f['hierarchy'] == 2:
                            if geom.intersects(merged_f1f0):
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if fda_name is not None:
                                    if f['group'] is None or f['group'] != fda_name:
                                        errorDict['Group Invalid'] += 1
                                        f_errors.append('Group_Invalid')
                                if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                    if f['status'] in [None, ''] or f['status'] not in [3, '3']: #3 = Engineered
                        errorDict['Wrong Status'] += 1
                        f_errors.append('Wrong_Status')
                    if f['physical_status'] in [None, ''] or f['physical_status'] != 2: #New Build = 2
                        errorDict['Wrong Physical Status'] += 1
                        f_errors.append('Wrong_Physical_Status')
                    if f['comments'] not in [None, ''] and f['type'] != 1: #Not Cabinet
                        errorDict['Comments Invalid'] += 1
                        f_errors.append('Comments_Invalid')
                    if f['comments']in [None, ''] and f['type'] == 1: #Cabinet
                        errorDict['Comments Invalid'] += 1
                        f_errors.append('Comments_Invalid')    
                    if (f['type'] is not None and f['type'] == 1) and (f['j_s_type'] is None or f['j_s_type'] not in [4, 1]):
                        errorDict['Type Mismatch'] += 1
                        f_errors.append('Type_Mismatch')
                    if (f['type'] not in [None, 1, 2]):  #Cabinet = 1, Handhole = 2
                        errorDict['Type Mismatch'] += 1
                        f_errors.append('Type_Mismatch')
                    
                    #12x12x12 - Type Flower Pot. Only contains max Fiber count 2
                    if f['size'] == 1 and f['j_fibercounts'] not in [None, '2']:
                        errorDict['Size/Fibercount Mismatch']
                        f_errors.append('Size/Fibercount_Mismatch')
                    elif f['size'] != 1 and f['j_fibercounts'] in ['2']:
                        errorDict['Size/Fibercount Mismatch']
                        f_errors.append('Size/Fibercount_Mismatch')
                    #13x24x18 - Contains max Fiber count 144. Can contain slack loop or MST. Can not contain Splice
                    if f['size'] == 2 and f['j_fibercounts'] not in [None, ''] and max([int(x) for x in f['j_fibercounts'].split(',')]) != 144:
                        errorDict['Size/Fibercount Mismatch']
                        f_errors.append('Size/Fibercount_Mismatch')
                    if f['size'] ==2 and (f['j_s_type'] not in [None, 2]):
                        errorDict['Size/Splice Mismatch']
                        f_errors.append('Size/Splice_Mismatch')
                    #24x36x24 - Contains Fiber >144. Can contain B sized splice (BGEL - 450)

                    if f['size'] == 3 and f['j_fibercounts'] not in [None,''] and min([int(x) for x in f['j_fibercounts'].split(',')]) <= 144:
                        errorDict['Size/Fibercount Mismatch']
                        f_errors.append('Size/Fibercount_Mismatch')
                    if f['size'] == 3 and (f['j_s_type'] not in [None, 3] or (f['j_s_type'] == 3 and f['j_s_material'] == 2)): #material 1: BGEL, 2:DGEL
                        errorDict['Size/Splice Mismatch']
                        f_errors.append('Size/Splice_Mismatch')
                    #30x48x24 - Cabinet mount or D size splice closure(DGEL - 450)
                    if f['size'] == 4 and (f['j_s_type'] not in [1, 4] or (f['j_s_type'] == 3 and f['j_s_material'] != 2)):
                        errorDict['Size/Fibercount Mismatch']
                        f_errors.append('Size/Fibercount_Mismatch')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    access_pts.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))
        finally:
            QgsProject.instance().removeMapLayer(access_spl_ele)    
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Access Points check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")

    def fibercable():
        start_time = datetime.now()
        dbox.append('FIBER CABLE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        processing.run("native:selectbylocation", {'INPUT':fibercables,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})

        #join : Segment
        segment_dissolve = processing.run("native:dissolve", {'INPUT': QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'FIELD':['segment_type'],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        segment_dissolve_buffer = processing.run("native:buffer", {'INPUT': segment_dissolve,'DISTANCE':0.9999979999999974,'SEGMENTS':1,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        fc_seg = processing.run("native:joinattributesbylocation", {'INPUT': QgsProcessingFeatureSourceDefinition(fibercables.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'PREDICATE':[5],'JOIN':segment_dissolve_buffer,'JOIN_FIELDS':[],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #Perform attribute join in-situ
        QgsProject.instance().addMapLayer(fc_seg)
        try:
            jlayer = project.mapLayersByName(fc_seg.name())[0]
            joinObject = QgsVectorLayerJoinInfo()
            joinObject.setJoinFieldName('uuid')
            joinObject.setTargetFieldName('uuid')
            joinObject.setJoinLayerId = jlayer.id()
            joinObject.setJoinLayer(jlayer)
            joinObject.setPrefix('j_')
            joinObject.setUsingMemoryCache(True)
            fibercables.addJoin(joinObject)
            fibercount_domain = {
                1: 2,
                2: 4,
                3: 6,
                4: 8,
                5: 12,
                6: 24,
                7: 48,
                8: 96,
                9: 144,
                10: 288,
                11: 432,
                12: 864
            }
            '''
            placement_type: 1: Aerial, 2: Direct Buried, 3: Indoor, 4: Underground
            segment_type:  2: Aerial, 4: Drop Cable, 9: Underground
            tags: 1: Bulk, 2: FET, 3: Flex Nap, 4: F2, 5: Drop
            cable_category: 1: Distribution, 2: Drop, 3: F1, 4:F2
            pysical_status: 1: Exisitng, 2: New Build
            '''
            errorDict = {
                "Group 1 Invalid": 0,
                "Fibercount Invalid" : 0,
                "Placement Type Invalid": 0,
                "Placement/Segment Type Mismatch": 0,
                "Tags Invalid": 0,
                "Cable Name Invalid": 0,
                "Tags/Fibercount Mismatch": 0,
                "Cable Category Invalid": 0,
                "Physical Status Invalid": 0,
                "Physical Status/Segment ID Mismatch": 0,
                "Segment ID Invalid": 0,
                "Fiber Strands Invalid": 0,
                "Hierarchy Invalid": 0,
                "Hierarchy/Geom Mismatch":0,
                "Tags\Category Mismatch":0
            }
            total = fibercables.selectedFeatureCount()
            if fibercables.isEditable():
                fibercables.commitChanges()
            with edit(fibercables):
                for idx, f in enumerate(fibercables.selectedFeatures(), 1):
                    f_errors = []
                    if f['hierarchy'] in [None, '']:
                        errorDict['Hierarchy Invalid'] += 1
                        f_errors.append('Hierarchy_Invalid')
                    else:
                        geom = f.geometry()
                        if f['hierarchy'] in [4,5,6,7]: #contains F0
                                f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                                if f0_segment_id is None:
                                    errorDict['Hierarchy/Geom Mismatch'] += 1
                                    f_errors.append('Hierarchy/Geometry_Mismatch')
                                elif f['segment_id'] in [None, ''] or f['segment_id'] != f0_segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                        elif f['hierarchy'] in [1,3]: #contains F1:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            elif f['segment_id'] in [None, ''] or f['segment_id'] != f1_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['hierarchy'] == 2:
                            if geom.intersects(merged_f1f0):
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if fda_name is not None:
                                    if f['group_1'] is None or f['group_1'] != fda_name:
                                        errorDict['Group 1 Invalid'] += 1
                                        f_errors.append('Group_1_Invalid')
                                if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')      

                    if f['fibercount'] in [None, '']:
                        errorDict['Fibercount Invalid'] += 1
                        f_errors.append("Fibercount_Invalid")
                    if f['placement_type'] in [None, '']:
                        errorDict['Placement Type Invalid'] += 1
                        f_errors.append("Placement_Type_Invalid")
                    elif (f['placement_type'] == 1 and f['j_segment_type'] != 2) or (f['placement_type'] == 4 and f['j_segment_type'] != 9) or (f['placement_type'] == 2 and f['j_segment_type'] not in [None, '']):
                        errorDict['Placement/Segment Type Mismatch'] += 1
                        f_errors.append('Placement/Segmnet_Type_Mismatch')
                    if f['tags'] in [None , '']: #tags: 1: Bulk, 2: FET, 3: Flex Nap, 4: F2, 5: DropTag
                        errorDict['Tags Invalid'] += 1
                        f_errors.append('Tags_Invalid')
                    elif f['tags'] == 5 and f['cable_category'] != 4: # tags = Drop, and category = F2 (not drop)
                        errorDict['Tags\Category Mismatch'] += 1
                        f_errors.append('Tags\Category_Mismatch')
                    elif f['tags'] == 5 and f['cable_name'] not in [None, '']: #5 = Drop
                        errorDict['Cable Name Invalid'] +=1
                        f_errors.append('Cable_Name_Invalid')
                    elif (f['tags'] == 1 and fibercount_domain[f['fibercount']] not in [48, 96, 144,288,432,864]) \
                        or (f['tags'] == 2 and fibercount_domain[f['fibercount']] not in [4,8,12]) \
                        or (f['tags'] == 5 and fibercount_domain[f['fibercount']] not in [2]):#We do not use 6 or 24 ct cables
                        errorDict['Tags/Fibercount Mismatch'] += 1
                        f_errors.append('Tags/Fibercount_Mismatch')
                    if all(x not in [None, ''] for x in [f['fibercount'], f['cable_name'], f['tags']]):
                        import re
                        category = 'DC' if f['tags'] == 1 and f['cable_category'] not in [2,3] else 'MST' if f['tags'] == 2 else 'Error' #1: Bulk, 2:FET
                        fiber_pattern = f"{str(fibercount_domain[f['fibercount']])}F"
                        pattern = rf"^{fiber_pattern}/{area_id}_{category}_\d{{3}}$"
                        if not bool(re.match(pattern, f['cable_name'])):
                            errorDict['Cable Name Invalid'] += 1
                            f_errors.append("Cable_Name_Invalid")
                    if f['cable_category'] in [None, '']:
                        errorDict['Cable Category Invalid'] += 1
                        f_errors.append('Cable_Category_Invalid')
                    if f['physical_status'] in [None, '']:
                        errorDict['Physical Status Invalid'] += 1
                        f_errors.append('Physical_Status_Invalid')
                    elif (f['segment_id'] is not None and f['physical_status'] != 2) or (f['segment_id'] in [None, ''] and f['physical_status'] != 1 ) :
                        errorDict['Physical Status/Segment ID Mismatch'] += 1
                        f_errors.append("Physical_Status/Segment_ID_Mismatch")
                    if f['fiber_strands'] in [None, '']:
                        errorDict['Fiber Strands Invalid'] += 1
                        f_errors.append('Fiber_Strands_Invalid')


                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    fibercables.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
        finally:
            QgsProject.instance().removeMapLayer(fc_seg)    
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Fiber Cable check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    def nap():
        start_time = datetime.now()
        dbox.append('NAP BOUNDARY CHECKS')
        dbox.append('____________________________________________________________________________________________')
        try:#predicate 6 = are within
            processing.run("native:selectbylocation", {'INPUT':nap_boundary,'PREDICATE':[6],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            withinCount = nap_boundary.selectedFeatureCount()
            processing.run("native:selectbylocation", {'INPUT':nap_boundary,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            intersectCount = nap_boundary.selectedFeatureCount()
            if withinCount < intersectCount:
                diff = intersectCount - withinCount
                dbox.append(warningFormat.format(f'{str(diff)} NAP Boundaries are not completely within the selected Zone. Fix geometries for accurate results.'))
            processing.run("native:selectbylocation", {'INPUT':splicings,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(nap_boundary.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            
            processing.run("native:selectbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(nap_boundary.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            processing.run("native:selectbylocation", {'INPUT':fibercables,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(nap_boundary.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
            naps = processing.run("native:saveselectedfeatures", {'INPUT':nap_boundary,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #Filter for MSTs in Splicing layer
            msts = processing.run("native:extractbyexpression", {'INPUT':QgsProcessingFeatureSourceDefinition(splicings.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'EXPRESSION':'type = 2','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #Filter for Site which are connected to a drop/fibercable. "Include In Build Plan" is not filled out in Corsicana, and is therefore, unreliable.  
            processing.run("native:selectbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(fibercables.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':2})      
            #Get count of valid sites within each NAP
            naps_sitesCount = processing.run("native:countpointsinpolygon", {'POLYGONS':naps,'POINTS':QgsProcessingFeatureSourceDefinition(sites.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'WEIGHT':'','CLASSFIELD':'','FIELD':'NUMPOINTS','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #Get count of mst within each NAP, >1 is bad
            mstCount = processing.run("native:countpointsinpolygon", {'POLYGONS':naps,'POINTS': msts,'WEIGHT':'','CLASSFIELD':'','FIELD':'NUMMST','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            naps_sitesCount_msts = processing.run("native:joinattributesbylocation", {'INPUT':naps_sitesCount,'PREDICATE':[0],'JOIN': msts,'JOIN_FIELDS':['tags','type', 'material', 'aka'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'s_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            naps_sitesCount_msts_mstCount = processing.run("native:joinattributesbylocation", {'INPUT':naps_sitesCount_msts,'PREDICATE':[0],'JOIN': mstCount,'JOIN_FIELDS':['NUMMST'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'m_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            QgsProject.instance().addMapLayer(naps_sitesCount_msts_mstCount)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
            return
        try:
            #Do the Attribute Join
            
            jlayer = project.mapLayersByName(naps_sitesCount_msts_mstCount.name())[0]
            joinObject = QgsVectorLayerJoinInfo()
            joinObject.setJoinFieldName('uuid')
            joinObject.setTargetFieldName('uuid')
            joinObject.setJoinLayerId = jlayer.id()
            joinObject.setJoinLayer(jlayer)
            joinObject.setPrefix('j_')
            joinObject.setUsingMemoryCache(True)
            nap_boundary.addJoin(joinObject)

            errorDict = {
                "Segment ID Invalid": 0,
                "Zone Name Invalid": 0,
                "Area Name Invalid": 0,
                "Boundary Type Invalid": 0,
                "Invalid Num HHP": 0,
                "Num HHP Count Mismatch": 0,
                "No MST In NAP": 0, 
                "Area Name/MST Name Mismatch": 0
            }
            total = nap_boundary.selectedFeatureCount()
            if nap_boundary.isEditable():
                nap_boundary.commitChanges()
            with edit(nap_boundary):
                for idx, f in enumerate(nap_boundary.selectedFeatures(), 1):
                    f_errors = []
                    if f['j_m_NUMMST'] == 0:
                        errorDict['No MST In NAP'] += 1
                        f_errors.append("No_MST_In_NAP")
                    elif f['area_name'] in [None, '']:
                        errorDict['Area Name Invalid'] += 1
                        f_errors.append("Area_Name_Invalid")
                    elif f['area_name'] != f['j_s_aka']:
                        errorDict['Area Name/MST Name Mismatch'] += 1
                        f_errors.append("Area_Name/MST_Name_Mismatch")
                    elif fda_name not in f['area_name']: # 
                        continue #Skip it, it's not within the zone we are 
                    if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                        errorDict['Segment ID Invalid'] += 1
                        f_errors.append('Segment_ID_Invalid')
                    if f['zone_name'] in [None, ''] or f['zone_name'] != segment_id:
                        errorDict['Zone Name Invalid'] += 1
                        f_errors.append("Zone_Name_Invalid")    
                    if f['boundary_type'] in [None, ''] or f['boundary_type'] != 'NAP_Boundary':
                        errorDict['Boundary Type Invalid'] += 1
                        f_errors.append('Boundary_Type_Invalid')
                        
                    if f['num_hhp'] in [None, '']:
                        errorDict['Invalid Num HHP'] += 1
                        f_errors.append('Invalid_Num_HHP')
                    elif f['num_hhp'] != f['j_NUMPOINTS']:
                        errorDict['Num HHP Count Mismatch'] += 1
                        f_errors.append("Num_HHP_Count_Mismatch")

                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    nap_boundary.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
        finally:
            QgsProject.instance().removeMapLayer(naps_sitesCount_msts_mstCount)   

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"NAP Boundary check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
        
    def network_element():
        start_time = datetime.now()
        dbox.append('NETWORK ELEMENT CHECKS')
        dbox.append('____________________________________________________________________________________________')
        
        processing.run("native:selectbylocation", {'INPUT':network_elements,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        try:
            errorDict = {
                "Segment ID Invalid": 0,
                "Group Invalid": 0,
                "Element Type Invalid": 0,
                "Element Name Invalid": 0,
                "Size Invalid": 0,
                "Physical Status Invalid": 0,
                "Physical Status/Data Source Mismatch": 0,
                "Hierarchy Invalid": 0,
                
                
            }
            total = network_elements.selectedFeatureCount()
            if network_elements.isEditable():
                network_elements.commitChanges()
            with edit(network_elements):
                for idx, f in enumerate(network_elements.selectedFeatures(), 1):
                    f_errors = []
                    # Hierarchy 1: F1, 2: F2, 3: F1/F2, 4: F0, 5: F0/F1, 6: F0/F2, 7: F0/F1/F2
                    if f['hierarchy'] in [None, '']:
                        errorDict['Hierarchy Invalid'] += 1
                        f_errors.append('Hierarchy_Invalid')
                    else:
                        geom = f.geometry()
                        if f['hierarchy'] in [4,5,6,7]: #contains F0
                            f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                            if f0_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            elif f['segment_id'] in [None, ''] or f['segment_id'] != f0_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['hierarchy'] in [1,3]: #contains F1:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            elif f['segment_id'] in [None, ''] or f['segment_id'] != f1_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['hierarchy'] == 2:
                            if geom.intersects(merged_f1f0):
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if fda_name is not None:
                                    if f['group'] is None or f['group'] != fda_name:
                                        errorDict['Group Invalid'] += 1
                                        f_errors.append('Group_Invalid')
                                if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                    if f['element_type'] in [None, '']: #1 Anchor, 2 Riser, 3 Slack, 4 EBore Pit.....
                        errorDict['Element Type Invalid'] += 1
                        f_errors.append('Element_Type_Invalid')
                    else:
                        if f['element_type'] ==3 and (f['element_name'] in [None, ''] or any(x in f['element_name'] for x in ['(', ')'])):
                            errorDict['Element Name Invalid'] += 1
                            f_errors.append('Element_Name_Invalid')
                        elif f['element_type'] != 3 and f['element_name'] not in [None, '']:
                            errorDict['Element Name Invalid'] += 1
                            f_errors.append('Element_Name_Invalid')
                        if (f['element_type'] == 3 and f['size'] in [None, '']) or (f['element_type'] != 3 and f['size'] not in [None, '']):
                            errorDict['Size Invalid'] += 1
                            f_errors.append('Size_Invalid')
                    if f['physical_status'] in [None, '']:
                        errorDict['Physical Status Invalid'] += 1
                        f_errors.append('Physical_Status_Invalid')
                    elif f['data_source'] in [None, '']:
                        if f['physical_status'] != 2: #New Build
                            errorDict['Physical Status/Data Source Mismatch'] += 1
                            f_errors.append('Physical_Status/Data_Source_Mismatch')
                    elif 'Katapult' in f['data_source']:
                        if f['physical_status'] == 2:
                            #1 Existing, 2: NB
                            errorDict['Physical Status/Data Source Mismatch'] += 1
                            f_errors.append('Physical_Status/Data_Source_Mismatch')       
                    
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    network_elements.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
        
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Network Element check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")

    def pole():
        start_time = datetime.now()
        dbox.append('POLE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        
        processing.run("native:selectbylocation", {'INPUT':poles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        selectedPoles = processing.run("native:saveselectedfeatures", {'INPUT':poles,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #AE Fiber
        processing.run("native:selectbylocation", {'INPUT':fibercables,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("qgis:selectbyattribute", {'INPUT':fibercables,'FIELD':'placement_type','OPERATOR':0,'VALUE':'1','METHOD':3}) #selecting within current selection , value 1 = aerial   
        processing.run("native:selectbylocation", {'INPUT':selectedPoles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(fibercables.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':3})
        poles_not_attached = []
        for f in selectedPoles.selectedFeatures():
            poles_not_attached.append(f['uuid'])
        #AE Segments
        processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("qgis:selectbyattribute", {'INPUT':segments,'FIELD':'segment_type','OPERATOR':0,'VALUE':'2','METHOD':3}) #selecting within current selection , value 2 = aerial   
        processing.run("native:selectbylocation", {'INPUT':selectedPoles,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(fibercables.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':3})
        poles_not_attached_segment = []
        for f in selectedPoles.selectedFeatures():
            poles_not_attached_segment.append(f['uuid'])

        try:
            errorDict = {
                "Segment ID Invalid": 0,
                "Group 1 Invalid": 0,
                "Attach Invalid": 0,
                "Attach/Owner/MRE Flag": 0,
                'AE Fiber Cable Not Snapped to Pole': 0,
                'AE Segment Not Snapped to Pole': 0
            }
            total = poles.selectedFeatureCount()
            if poles.isEditable():
                poles.commitChanges()
            with edit(poles):
                for idx, f in enumerate(poles.selectedFeatures(), 1):
                    f_errors = []
                    if f['pole_group'] in [None, ''] or f['pole_group'] != fda_name:
                        errorDict['Group 1 Invalid'] += 1
                        f_errors.append('Group_1_Invalid')
                    if f['segment_id'] in [None, '']:
                        errorDict['Segment ID Invalid'] += 1
                        f_errors.append('Segment_ID_Invalid')
                    else:
                        geom = f.geometry()
                        f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                        if f0_segment_id is None:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                if f['segment_id'] != fda_name:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                            elif f['segment_id'] != f1_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['segment_id'] != f0_segment_id:
                            errorDict['Segment ID Invalid'] += 1
                            f_errors.append('Segment_ID_Invalid')
                    if f['attach'] is [None, '']:
                        errorDict['Attach Invalid'] += 1
                        f_errors.append('Attach_Invalid')
                    else:
                        if f['attach'] in ['Yes', 'yes'] and f['pole_owner'] in ['ATT', 'AT&T', 'att'] and f['make_ready_type'] in ['Power MR', 'Simple Power', 'LightPower', 'Power Rearrangement']:
                            errorDict['Attach/Owner/MRE Flag'] += 1
                            f_errors.append('Attach/Owner/MRE_Flag')
                        if f['attach'] in ['Yes', 'yes'] and f['uuid'] in poles_not_attached:
                            errorDict['AE Fiber Cable Not Snapped to Pole'] += 1
                            f_errors.append('AE_Fiber_Cable_Not_Snapped_To_Pole')
                        if f['attach'] in ['Yes', 'yes'] and f['uuid'] in poles_not_attached_segment:
                            errorDict['AE Segment Not Snapped to Pole'] += 1
                            f_errors.append('AE_Segment_Not_Snapped_To_Pole')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    poles.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Pole check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    def segment():
        start_time = datetime.now()
        dbox.append('SEGMENT CHECKS')
        dbox.append('____________________________________________________________________________________________')
        
        processing.run("native:selectbylocation", {'INPUT':segments,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("native:selectbylocation", {'INPUT':access_pts,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        #We only need access points that intersect with segment endpoints. For check Duct Count = 1 where segment terminates at 12x12x12
        endpoints = processing.run("native:extractspecificvertices", {'INPUT':QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'VERTICES':'-1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        endpoint_buffer = processing.run("native:buffer", {'INPUT':endpoints,'DISTANCE':1.9999959999999948,'SEGMENTS':5,'END_CAP_STYLE':0,'JOIN_STYLE':0,'MITER_LIMIT':2,'DISSOLVE':False,'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        processing.run("native:selectbylocation", {'INPUT':access_pts,'PREDICATE':[0],'INTERSECT': endpoint_buffer,'METHOD':0})
        
        segment_access = processing.run("native:joinattributesbylocation", {'INPUT':QgsProcessingFeatureSourceDefinition(segments.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'PREDICATE':[0],'JOIN': QgsProcessingFeatureSourceDefinition(access_pts.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'JOIN_FIELDS':['size'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'a_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        try:
            #Do the Attribute Join
            QgsProject.instance().addMapLayer(segment_access)
            jlayer = project.mapLayersByName(segment_access.name())[0]
            joinObject = QgsVectorLayerJoinInfo()
            joinObject.setJoinFieldName('uuid')
            joinObject.setTargetFieldName('uuid')
            joinObject.setJoinLayerId = jlayer.id()
            joinObject.setJoinLayer(jlayer)
            joinObject.setPrefix('j_')
            joinObject.setUsingMemoryCache(True)

            segments.addJoin(joinObject)
            errorDict = {
                "Segment ID Invalid": 0,
                "Group_1 Invalid": 0,
                "Physical Status Invalid": 0,
                "Segment Status Invalid": 0,
                "Type Invalid": 0,
                "Type/Duct Diameter Mismatch": 0,
                "Duct Count Invalid": 0,
                "Duct Count/Access Point Mismatch": 0

            }
            total = segments.selectedFeatureCount()
            if segments.isEditable():
                segments.commitChanges()
            with edit(segments):
                for idx, f in enumerate(segments.selectedFeatures(), 1):
                    f_errors = []
                    if f['group'] in [None, '']:
                        errorDict['Group_1 Invalid'] += 1
                        f_errors.append('Group_1__Invalid')
                    else:
                        geom = f.geometry()
                        f0_fda_name = next((f0_dict[x][2] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                        if f0_fda_name is None:
                            f1_fda_name = next((f1_dict[x][2] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_fda_name is None:
                                if f['group'] != fda_name:
                                    errorDict['Group_1 Invalid'] += 1
                                    f_errors.append('Group_1__Invalid')
                            elif f['group'] != f1_fda_name:
                                errorDict['Group_1 Invalid'] += 1
                                f_errors.append('Group_1__Invalid')
                        elif f['group'] != f0_fda_name:
                            errorDict['Group_1 Invalid'] += 1
                            f_errors.append('Group_1__Invalid')

                    if f['segment_id'] in [None, '']:
                        errorDict['Segment ID Invalid'] += 1
                        f_errors.append('Segment_ID_Invalid')
                    else:
                        geom = f.geometry()
                        f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                        if f0_segment_id is None:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                if f['segment_id'] != segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                            elif f['segment_id'] != f1_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['segment_id'] != f0_segment_id:
                            errorDict['Segment ID Invalid'] += 1
                            f_errors.append('Segment_ID_Invalid')

                    if f['physical_status'] in [None, '']:
                        errorDict['Physical Status Invalid'] += 1
                        f_errors.append('Physical_Status_Invalid')
                    elif f['physical_status'] != 2 and (f['data_source'] in [None, ''] or 'Katapult' not in f['data_source']):
                        errorDict['Physical Status Invalid'] += 1
                        f_errors.append('Physical_Status_Invalid')
                    if f['segment_status'] in [None, '']: 
                        errorDict['Segment Status Invalid'] += 1
                        f_errors.append('Segment_Status_Invalid')
                    elif f['segment_status'] != 3: # 3 Engineered
                        errorDict['Segment Status Invalid'] += 1
                        f_errors.append('Segment_Status_Invalid')
                    if f['type'] in [None, '']:
                        errorDict['Type Invalid'] += 1
                        f_errors.append('Type_Invalid')
                    elif f['type'] == 2:#2 AE
                        if f['duct_diameter'] not in [None, '']: #diameter is null/blank for aerial spans
                            errorDict['Type/Duct Diameter Mismatch'] += 1
                            f_errors.append('Type/Duct_Diameter_Mismatch')
                        if f['duct_count'] not in [None, ''] and f['duct_count'] != 0:
                            errorDict['Duct Count Invalid'] += 1
                            f_errors.append('Duct_Count_Invalid')
                    elif f['type'] == 9:#9 UG
                        if f['duct_diameter'] is not None and  f['duct_diameter'] not in [2, 16]:#diameter is .75 or 1.25 for ug
                            errorDict['Type/Duct Diameter Mismatch'] += 1
                            f_errors.append('Type/Duct_Diameter_Mismatch')
                        if f['duct_count'] in [None, ''] or f['duct_count'] not in [1,3,4,6,7,9]:
                            errorDict['Duct Count Invalid'] += 1
                            f_errors.append('Duct_Count_Invalid')
                    if f['duct_count'] not in [None, ''] and f['duct_count'] == 1 and f['j_a_size'] != 1:
                        errorDict['Duct Count/Access Point Mismatch'] += 1
                        f_errors.append('Duct_Count/Access_Point_Mismatch')
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    segments.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
        finally:
            QgsProject.instance().removeMapLayer(segment_access)    
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Segment check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")

    def site():
        start_time = datetime.now()
        dbox.append('SITE CHECKS')
        dbox.append('____________________________________________________________________________________________')
        
        processing.run("native:selectbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        processing.run("native:selectbylocation", {'INPUT':fibercables,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})

        processing.run("native:selectbylocation", {'INPUT':sites,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(fibercables.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':2})

        try:
            errorDict = {
                "Segment ID Invalid": 0,
                "Group_1 Invalid": 0,
                "Include In Build Plan Invalid": 0,
                "BEN Invalid": 0,
                "Address Invalid": 0,
                "City Invalid": 0,
                "State Invalid": 0,
                "Zip Code Invalid": 0,
                "Site Type Invalid": 0

            }
            total = sites.selectedFeatureCount()
            if sites.isEditable():
                sites.commitChanges()
            with edit(sites):
                for idx, f in enumerate(sites.selectedFeatures(), 1):
                    f_errors = []
                    try:
                        if f['group_1'] in [None, ''] or f['group_1'] != fda_name: #Group 1
                            errorDict['Group_1 Invalid'] += 1
                            f_errors.append('Group_1_Invalid')
                    except: #some projects have Group 1 field as site_group, and others use group_1
                        try:
                            if f['site_group'] in [None, ''] or f['site_group'] != fda_name: #Group 1
                                errorDict['Group_1 Invalid'] += 1
                                f_errors.append('Group_1_Invalid')
                        except Exception as e:
                            exc_type, exc_value, exc_traceback = sys.exc_info()
                            line_number = exc_traceback.tb_lineno
                            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))
                    if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                        errorDict['Segment ID Invalid'] += 1
                        f_errors.append('Segment_ID_Invalid')
                    if f['include_in_build_plan'] in [None, '', 1]: #1 No, 2 Yes
                        errorDict['Include In Build Plan Invalid'] += 1
                        f_errors.append('Include_In_Build_Plan_Invalid')
                    if f['ben_'] in [None, '']:
                        errorDict['BEN Invalid'] += 1
                        f_errors.append('BEN_Invalid')
                    if f['address'] in [None, '']:
                        errorDict['Address Invalid'] += 1
                        f_errors.append('Address_Invalid')
                    if f['city'] in [None, '']:
                        errorDict['City Invalid'] += 1
                        f_errors.append('CITY_Invalid')
                    if f['state'] in [None, '']:
                        errorDict['State Invalid'] += 1
                        f_errors.append('State_Invalid')
                    if f['zip_code'] in [None, '']:
                        errorDict['Zip Code Invalid'] += 1
                        f_errors.append('Zip_Code_Invalid')
                    if f['site_type'] in [None, '']:
                        errorDict['Site Type Invalid'] += 1
                        f_errors.append('Site_Type_Invalid')
                    
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    sites.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  

        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Site check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    def splicing():
        start_time = datetime.now()
        dbox.append('SPLICING CHECKS')
        dbox.append('____________________________________________________________________________________________')
        
        processing.run("native:selectbylocation", {'INPUT':splicings,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(selectedBound.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
        try:
            errorDict = {
                "Group 2 Invalid": 0,
                "Segment ID Invalid": 0,
                "Physical Status Invalid": 0,
                "Fiber Assignments Invalid": 0,
                "Hierarchy Invalid": 0,
                'Hierarchy/Geom Mismatch':0,
                "Type Invalid": 0,
                "Type/Material Mismatch": 0,
                "Tags Invalid": 0,
                "Subtype Invalid":0,
                "AKA Invalid": 0,
                "Type/AKA Mismatch": 0

            }
            total = splicings.selectedFeatureCount()
            if splicings.isEditable():
                splicings.commitChanges()
            with edit(splicings):
                for idx, f in enumerate(splicings.selectedFeatures(), 1):
                    f_errors = []
                    # Hierarchy 1: F1, 2: F2, 3: F1/F2, 4: F0, 5: F0/F1, 6: F0/F2, 7: F0/F1/F2
                    if f['hierarchy'] in [None, '']:
                        errorDict['Hierarchy Invalid'] += 1
                        f_errors.append('Hierarchy_Invalid')
                    else:
                        geom = f.geometry()
                        if f['hierarchy'] in [4,5,6,7]: #contains F0
                            f0_segment_id = next((f0_dict[x][0] for x in f0_dict if geom.intersects(f0_dict[x][1])), None)
                            if f0_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            elif f['segment_id'] in [None, ''] or f['segment_id'] != f0_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['hierarchy'] in [1,3]: #contains F1:
                            f1_segment_id = next((f1_dict[x][0] for x in f1_dict if geom.intersects(f1_dict[x][1])), None)
                            if f1_segment_id is None:
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            elif f['segment_id'] in [None, ''] or f['segment_id'] != f1_segment_id:
                                errorDict['Segment ID Invalid'] += 1
                                f_errors.append('Segment_ID_Invalid')
                        elif f['hierarchy'] == 2:
                            if geom.intersects(merged_f1f0):
                                errorDict['Hierarchy/Geom Mismatch'] += 1
                                f_errors.append('Hierarchy/Geometry_Mismatch')
                            else:
                                if fda_name is not None:
                                    if f['group_2'] is None or f['group_2'] != fda_name:
                                        errorDict['Group 2 Invalid'] += 1
                                        f_errors.append('Group_2_Invalid')
                                if f['segment_id'] in [None, ''] or f['segment_id'] != segment_id:
                                    errorDict['Segment ID Invalid'] += 1
                                    f_errors.append('Segment_ID_Invalid')
                    if f['physical_status'] is [None, ''] or f['physical_status'] != 2:
                        errorDict['Physical Status Invalid'] += 1
                        f_errors.append('Physical_Status_Invalid')

                    if f['type'] in [None, '']: #type 1: FTP, 2: MST, 3: Splice, 4: OLT
                        errorDict['Type Invalid'] += 1
                        f_errors.append('Type_Invalid')
                    else:
                        if f['fiber_assign'] in [None, '', 'NULL'] and f['type'] in [1, 2]: #Must not be Null if FTP/MST
                            errorDict['Fiber Assignments Invalid'] += 1
                            f_errors.append('Fiber_Assignments_Invalid')    
                        elif f['fiber_assign'] not in [None, '', 'NULL'] and f['type'] in [3, 4]:#Must be Null if Splice/OLT
                            errorDict['Fiber Assignments Invalid'] += 1
                            f_errors.append('Fiber_Assignments_Invalid')
                        
                        if f['type'] in [1, 2] and f['material'] not in [None, '', 'NULL']:
                            errorDict['Type/Material Mismatch'] += 1
                            f_errors.append('Type/Material_Mismatch')
                        elif f['type'] in [3, 4] and f['material'] in [None, '', 'NULL']:
                            errorDict['Type/Material Mismatch'] += 1
                            f_errors.append('Type/Material_Mismatch')
                    
                    if f['tail_length'] in [None, '', 'Error']: #"Tags" alias is tail_length
                        errorDict['Tags Invalid'] += 1
                        f_errors.append('Tags_Invalid')
                    if f['tags'] in [None, '']: #"Subtype" alias is tags
                        errorDict['Subtype Invalid'] +=1
                        f_errors.append('Subtype_Invalid')
                    if f['aka'] in [None, '']:
                        errorDict['AKA Invalid'] += 1
                        f_errors.append('AKA_Invalid')
                    elif f['type'] is not None and\
                        ((f['type'] == 1 and fda_name not in f['aka']) or\
                        (f['type'] == 2 and f'{fda_name}_MST' not in f['aka']) or\
                        (f['type'] == 3 and 'SP' not in f['aka']) or\
                        (f['type'] == 4 and wire_center not in f['aka'])):
                        errorDict['Type/AKA Mismatch']
                        f_errors.append('Type/AKA_Mismatch')
                    
                    #update
                    f['qc_errors'] = ', '.join(f_errors) if len(f_errors) > 0 else 'None'
                    splicings.updateFeature(f)
                    progress = int((idx / total) * 100)
                    functionProgressBar.setValue(progress)

        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
 
        #Error Summary
        for key, value in errorDict.items():
            if value > 0:
                dbox.append(f'{warningFormat.format(f"{key}: {value}")}')
        #Time Stamps
        end_time = datetime.now()
        elapsed = end_time - start_time
        dbox.append(f"Splicing check completed in {elapsed.seconds // 60} min {elapsed.seconds % 60} sec")
    
    #if len(geom_checks)>0:
    ##    __invalid_geoms__(project_name, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat,geom_checks)
    #else:
    #    print('geometry check box not checked')
    progressBar.setValue(12)
    if qcCheckButton:
        dbox.append(str(qcChecks))
        val = 0
        if "Cabinet Boundary" in qcChecks:
            cabinet()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "Access Point" in qcChecks:
            access_points()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "Pole" in qcChecks: #no hierarchy, Not sure how those get uploaded
            pole()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "Segments" in qcChecks: #no hierarchy, maybe look at centroid?
            segment()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "Site" in qcChecks and fda_name not in ['F0', 'F1']:
            site()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "Splicing" in qcChecks:    
            splicing()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "Fiber Cable" in qcChecks:
            fibercable()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "Network Element" in qcChecks:
            network_element()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        if "NAP Boundary" in qcChecks and fda_name not in ['F0', 'F1']:
            nap()
            val += 1
            progressBar.setValue(int((val/len(qcChecks))*100))
            QCoreApplication.processEvents()
        
        
        
        
