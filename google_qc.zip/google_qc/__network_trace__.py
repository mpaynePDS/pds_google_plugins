# -*- coding: utf-8 -*-
"""
Created on Tues July 25, 2025
Vero QC - geometry Checks
@author: Marie Payne
"""
# import geopandas as gpd
import pandas as pd
# import openpyxl
#from _typeshed import FileDescriptor
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject,QgsSpatialIndex, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsPointXY, QgsVectorLayer, QgsVectorLayerJoinInfo,\
                     edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest, QgsFeature,QgsField, QgsFields,QgsCoordinateReferenceSystem
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __network_trace__(dbox,  progressBar, functionProgressBar, errorFormat, warningFormat, validFormat, geometriesListWidget):
    # Define layers
    dbox.append('Fixing Line Direction \n____________________________________________________________________________________________')
    project = QgsProject.instance()
    fiber_cable = project.mapLayersByName('Fiber_Cable')[0]
    access_point = project.mapLayersByName('Access_Point')[0]
    pole = project.mapLayersByName('Pole')[0]
    splicing = project.mapLayersByName('Splicing')[0]
    site = project.mapLayersByName('Site')[0]
    ''' QC Requirements:
    - FC must have names if not a drop
    - FC must have fibercount
    - Splicing must have type and aka

    '''
    
    try:
        #QC
        errors = {
        "Null Fibercount": 0,
        "Null Tags": 0,
        "Null Category": 0,
        "Drops With Name": 0,
        "Bulk Fiber or Tails Missing Name": 0}
        for fc in fiber_cable.getFeatures():
            if fc['fibercount'] in [None, '']:
                errors["Null Fibercount"] += 1
            if fc['tags'] in [None, '']:
                errors["Null Tags"] += 1
            if fc['cable_category'] in [None, '']:
                errors["Null Category"] += 1

            if fc['tags'] is not None and fc['tags'] == 5 and fc['cable_category'] is not None and fc['cable_category'] == 2:
                if fc['cable_name'] is not None:
                    errors["Drops With Name"] += 1
            elif fc['tags'] not in [None, 5] and fc['cable_category'] not in [None, 2]:
                if fc['cable_name'] in [None, '']:
                    errors["Bulk Fiber or Tails Missing Name"] += 1
        dbox.append("\n".join([f"{errors[x]} {x}" for x in errors]))
        return
                    
                
    except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
            return
    try:
        #Extract FC start/endpoints
        fc = processing.run("native:extractspecificvertices", {'INPUT':fiber_cable,'VERTICES':'0,-1','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #Join Access Points to FC endpoints
        fc_access = processing.run("native:joinattributesbylocation", {'INPUT':fc,'PREDICATE':[0],'JOIN':access_point,'JOIN_FIELDS':['uuid'],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'a_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        #Join Poles to FC Endpoints
        fc_access_pole = processing.run("native:joinattributesbylocation", {'INPUT':fc_access,'PREDICATE':[0],'JOIN':pole,'JOIN_FIELDS':['uuid'],'METHOD':1,'DISCARD_NONMATCHING':False,'PREFIX':'p_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        fc_access_pole_splice = processing.run("native:joinattributesbylocation", {'INPUT':fc_access_pole,'PREDICATE':[0],'JOIN':splicing,'JOIN_FIELDS':['uuid','type', 'aka'],'METHOD':1,'DISCARD_NONMATCHING':False,'PREFIX':'s_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
        fc_access_pole_splice_site = processing.run("native:joinattributesbylocation", {'INPUT':fc_access_pole_splice,'PREDICATE':[0],'JOIN':site,'JOIN_FIELDS':['uuid'],'METHOD':1,'DISCARD_NONMATCHING':False,'PREFIX':'site_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
    except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}')) 
            return
    ''' Domains
    tags: 1: Bulk, 2: FET, 3: Flex Nap, 4: F2, 5: Drop
    cable_category: 1: Distribution, 2: Drop, 3: F1, 4:F2
    fibercount = 1: 2,
                2: 4,
                3: 6,
                4: 8,
                5: 12,
                6: 24,
                7: 48,
                8: 96,
                9: 144,
                10: 288,
                11: 432,
                12: 864
    splicing type: 1: FTP, 2: MST, 3: SPlice, 4: OLT
    '''
    #-Trace--------------------------------------------------------------------------------
    try:
        fields = fc_access_pole_splice_site.fields()
        column_names = [field.name() for field in fields]
        data = []
        for feature in fc_access_pole_splice_site.getFeatures():
            data.append(feature.attributes())
        df= pd.DataFrame(data, columns=column_names)
        flip = []
        # F0 
        f0_filter = df[(df['s_type'] == 4) & (df['cable_name'].str.contains('F0'))]
        if len(f0_filter)>1:
            dbox.append('Too many F0 cables!')
            return
        elif len(f0_filter) == 0:
            dbox.append('No F0 fibers found. No OLT origin point.')
            return
        elif f0_filter.iloc[0]['verex_pos'] != -1: 
            flip.append(f0_filter.iloc[0]['uuid'])
        else:
            f0_end = [f0_filter.iloc[0]['s_uuid']]
            last_pos = [f0_filter.iloc[0]['a_uuid'], [f0_filter.iloc[0]['p_uuid']]]
        f0_cables = f0_filter['cable_name'].unique()
        dbox.append(f'F0 Cables: {f0_cables}')
        # F1
        f1_filter = df[(df['tags'] == 1) & (df['cable_category'] == 3) & (~df['cable_name'].str.contains('F0'))]
        f1_cables = [f for f in f1_filter['cable_name'].unique() if 'F1' in f]
        dbox.append(f'F1 Cables: {f1_cables}')
        ftps = {}
        for c in f1_cables: #each f1 will end at an FSP splice point
            c_uuids = df[(df['cable_name'] == c)]['uuid'].unique()
            last_uuid = None
            error = False
            while len(c_uuids>0):
                start = False
                end = False
                #start from OLT
                for index, f in f1_filter.iterrows():
                    if f['uuid'] in c_uuids and f['a_uuid'] == last_pos[0] and f['p_uuid'] == last_pos[1]:
                            if f['vertex_pos'] != 0:
                                flip.append(f['uuid'])
                            last_uuid = f['uuid']
                            start = True
                            break
                if start == False:
                    dbox.append(f'No start for cable {c}, uuid {f['uuid']}.')
                    error = True
                    break #break while
                #end
                for index, f in f1_filter.iterrows():
                    if len(c_uuids) == 1:
                        if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]) and 'FSP' in f['s_aka']:
                            c_uuids.remove(last_uuid)#remove on ends only
                            last_pos = [f['a_uuid'], f['p_uuid']]
                            end = True
                            break
                    else:
                        if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]):
                            c_uuids.remove(last_uuid)#remove on ends only
                            last_pos = [f['a_uuid'], f['p_uuid']]
                            end = True
                            break
                if end == False:
                    dbox.append(f'No end for cable {c}.')
                    error = True
                    break #break while
            #F1 cables go all the way to the FTP. The last segment starts at a splice point and changes names to 'HDC'. HDC may loop!
            if not error:
                start = False
                end = False
                #start
                for index, f in f1_filter.iterrows():
                    if 'HDC' in f['cable_name'] and f['a_uuid'] == last_pos[0] and f['p_uuid'] == last_pos[1] and 'FSP' in f['s_aka']:
                            if f['vertex_pos'] != 0:
                                flip.append(f['uuid'])
                            last_uuid = f['uuid']
                            start = True
                            break
                if start == False:
                    dbox.append(f'No HDC start for cable {c}.')
                    error = True
                    break #break while
                #end
                for index, f in f1_filter.iterrows():
                    if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]) and f['s_type'] == 1: #1=FTP
                        last_pos = [f['a_uuid'], f['p_uuid']]
                        end = True
                        ftps[f['s_aka']] = last_pos
                        break
                        #Do we need to record the FTP last_pos for F2 loop?
                if end == False:
                    dbox.append(f'No FTP end for cable {c}.')
                    error = True
                    break #break while

        # F2
        '''Notes: F2 has standard 'DC' name and then an "HDC" for splices on top of cabinets. HDC may loop!
        '''
        f2_filter = df[(df['tags'] == 1) & (df['cable_category'] == 4)]#Bulk F2
        f2_cables = [f for f in f2_filter['cable_name'].unique() if '_DC' in f]
        splices = df[(df['s_type'] == 3)]['s_aka'].unique()#Splice uuids    
        for ftp in ftps:
            last_pos = ftps[ftp]    
            ftp_cables = f2_filter[(f2_filter['a_uuid'] == last_pos[0]) & f2_filter['p_uuid'] == last_pos[1]]['uuid'].unique()
            splice_dict = {}
            for c in ftp_cables: #each f2 will end at an MCA or Reel End
                c_uuids = df[(df['cable_name'] == c)]['uuid'].unique()
                last_uuid = None
                error = False
                while len(c_uuids>0):
                    start = False
                    end = False
                    #start from OLT
                    for index, f in f2_filter.iterrows():
                        if f['uuid'] in c_uuids and f['a_uuid'] == last_pos[0] and f['p_uuid'] == last_pos[1]:
                                if f['vertex_pos'] != 0:
                                    flip.append(f['uuid'])
                                last_uuid = f['uuid']
                                start = True
                                break
                    if start == False:
                        dbox.append(f'No start for cable {c}, uuid {f['uuid']}.')
                        error = True
                        break #break while
                    #end
                    for index, f in f2_filter.iterrows():
                        if len(c_uuids) == 1:
                            if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]) and 'SP' in f['s_aka'] and f['s_type'] in [3]: # Splice (MCA/RE)
                                c_uuids.remove(last_uuid)#remove on ends only
                                last_pos = [f['a_uuid'], f['p_uuid']]
                                splice = f['s_aka']
                                end = True
                                break
                        else:
                            if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]):
                                c_uuids.remove(last_uuid)#remove on ends only
                                last_pos = [f['a_uuid'], f['p_uuid']]
                                end = True
                                break
                    if end == False:
                        dbox.append(f'No end for cable {c}.')
                        error = True
                        break #break while
                    else:
                        splice_dict[splice] = last_pos
                #####################3
                if not error:
                    start = False
                    end = False
            # part two where there is a continuation of the same leg, but the cable name changes. This loops until all splices (MCA/RE) are found.
            while len(splices)>0:
                for s in splice_dict:
                    last_pos = splice_dict[s] 
                    cables = f2_filter[(f2_filter['a_uuid'] == last_pos[0]) & f2_filter['p_uuid'] == last_pos[1]]['uuid'].unique()
                    new_splice_dict = {}
                    for c in cables: #each f2 will end at an MCA or Reel End
                        c_uuids = df[(df['cable_name'] == c)]['uuid'].unique()
                        last_uuid = None
                        error = False
                        while len(c_uuids>0):
                            start = False
                            end = False
                            #start from OLT
                            for index, f in f2_filter.iterrows():
                                if f['uuid'] in c_uuids and f['a_uuid'] == last_pos[0] and f['p_uuid'] == last_pos[1]:
                                        if f['vertex_pos'] != 0:
                                            flip.append(f['uuid'])
                                        last_uuid = f['uuid']
                                        start = True
                                        break #break for
                            if start == False:
                                dbox.append(f'No start for cable {c}, uuid {f['uuid']}.')
                                error = True
                                break #break while
                            #end
                            for index, f in f2_filter.iterrows():
                                if len(c_uuids) == 1:
                                    if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]) and 'SP' in f['s_aka'] and f['s_type'] in [3]: # Splice (MCA/RE)
                                        c_uuids.remove(last_uuid)#remove on ends only
                                        last_pos = [f['a_uuid'], f['p_uuid']]
                                        splice = f['s_aka']
                                        end = True
                                        break#break for
                                else:
                                    if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]):
                                        c_uuids.remove(last_uuid)#remove on ends only
                                        last_pos = [f['a_uuid'], f['p_uuid']]
                                        end = True
                                        break#break for
                            if end == False:
                                dbox.append(f'No end for cable {c}.')
                                error = True
                                break #break while
                            else:
                                new_splice_dict[splice] = last_pos
                                splices.remove(splice)
                        #####################3
                        if not error:
                            start = False
                            end = False
                splice_dict = new_splice_dict

        # Tails
        '''Notes: Tails have MST in name. Tail must END at an MST. 
        '''
        tail_filter = df[(df['tags'] == 2) & (df['cable_category'] == 1)]#Fiber Equipment Tail, Distribution
        tails = [f for f in tail_filter['cable_name'].unique() if '_MST' in f]
        msts = df[(df['s_type'] == 2)]['s_aka'].unique()#MST names    
        splices = []
        mst_dict = {}
        for index, row in tail_filter.iterrows():
            if row['s_type'] in 3:#MCA/RE = start points for all MSTs
                splices.append([row['a_uuid'], row['p_uuid']])
        for s in splices:
            last_pos = s
            cables = tail_filter[(tail_filter['a_uuid'] == last_pos[0]) & tail_filter['p_uuid'] == last_pos[1]]['uuid'].unique()
            for c in cables: #each f2 will end at an MCA or Reel End
                c_uuids = df[(df['cable_name'] == c)]['uuid'].unique()
                last_uuid = None
                error = False
                while len(c_uuids>0):
                    start = False
                    end = False
                    #start from OLT
                    for index, f in f2_filter.iterrows():
                        if f['uuid'] in c_uuids and f['a_uuid'] == last_pos[0] and f['p_uuid'] == last_pos[1]:
                                if f['vertex_pos'] != 0:
                                    flip.append(f['uuid'])
                                last_uuid = f['uuid']
                                start = True
                                break
                    if start == False:
                        dbox.append(f'No start for cable {c}, uuid {f['uuid']}.')
                        error = True
                        break #break while
                    #end
                    for index, f in f2_filter.iterrows():
                        if len(c_uuids) == 1:
                            if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]) and 'MST' in f['s_aka'] and f['s_type'] in [2]: # MST
                                c_uuids.remove(last_uuid)#remove on ends only
                                last_pos = [f['a_uuid'], f['p_uuid']]
                                mst = f['s_aka']
                                end = True
                                break
                        else:
                            if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]):
                                c_uuids.remove(last_uuid)#remove on ends only
                                last_pos = [f['a_uuid'], f['p_uuid']]
                                end = True
                                break
                    if end == False:
                        dbox.append(f'No end for cable {c}.')
                        error = True
                        break #break while
                    else:
                        mst_dict[mst] = last_pos
                #####################3
                if not error:
                    start = False
                    end = False

        # Drops
        '''Notes: Drops have no name and terminate at a site. As such, we can't trace each cable individually. If a drop does not terminate at a site, then check for a split drop. 
        '''
        drop_filter = df[(df['tags'] == 5) & (df['cable_category'] == 2)]# Drop, Drop
        #drops = [f for f in drop_filter['cable_name'].unique() if '_MST' in f]
        splices = []
        for index, row in drop_filter.iterrows():
            if row['s_type'] in 3:
                splices.append([row['a_uuid'], row['p_uuid']])
        splits = []
        while len(splices)>0:
            for s in splices:
                last_pos = splices[s]
                cables = drop_filter[(drop_filter['a_uuid'] == last_pos[0]) & drop_filter['p_uuid'] == last_pos[1]]['uuid'].unique()
                mst_dict = {}
                for c in cables: 
                    error = False
                    start = False
                    end = False
                    #start from OLT
                    for index, f in f2_filter.iterrows():
                        if f['uuid'] == c and f['a_uuid'] == last_pos[0] and f['p_uuid'] == last_pos[1]:
                                if f['vertex_pos'] != 0:
                                    flip.append(f['uuid'])
                                last_uuid = f['uuid']
                                
                                start = True
                                break
                    if start == False:
                        dbox.append(f'No start for cable {c}, uuid {f['uuid']}.')
                        error = True
                        break #break while
                    #end
                    for index, f in f2_filter.iterrows():
                        if f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]) and f['site_uuid'] not in [None, '']: #site
                            last_pos = [f['a_uuid'], f['p_uuid']]
                            end = True
                            break

                        elif f['uuid'] == last_uuid and (f['a_uuid'] != last_pos[0] or f['p_uuid'] != last_pos[1]) and f['site_uuid'] in [None, '']: #site:
                            last_pos = [f['a_uuid'], f['p_uuid']]
                            if last_pos not in splits:
                                splits.append(last_pos)
                            end = True
                            break
                    if end == False:
                        dbox.append(f'No end for cable {c}.')
                        error = True
                        break #break while
            if len(splits)>0:
                splices = splits
                splits = []   
    except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
 
           
    



                        


                    
                




        
            
        

            
            
        


