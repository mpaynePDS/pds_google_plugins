# -*- coding: utf-8 -*-
"""
Created on Monday, July 21, 2025
Vero QC LLD
@author: Marie Payne
"""
# import geopandas as gpd
# import pandas as pd
# import openpyxl
import sys
# import warnings
import os
# from datetime import datetime
# import time
# import math
from .__geomChecks__ import __invalid_geoms__
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsVectorFileWriter, QgsWkbTypes, QgsField, QgsGeometry, QgsVectorLayer, QgsVectorLayerJoinInfo, edit,QgsProcessingFeatureSourceDefinition, QgsFeatureRequest,  QgsSpatialIndex, QgsPointXY, QgsDistanceArea
from qgis import processing
from PyQt5.QtCore import QVariant, QFileInfo, Qt
from datetime import datetime

def __permit_footage__(bound, outputfolder, dbox, progressBar, functionProgressBar, errorFormat, warningFormat, validFormat):

    try:
        dbox.append(f'Permit Footage Calculation at {datetime.now()}')
        full_start_time = datetime.now()
        project = QgsProject.instance()

        #layers
        proj_lyr = project.mapLayersByName('project')[0]
        permit_lyr= project.mapLayersByName('permit_polygons')[0]
        path_lyr = project.mapLayersByName('path')[0]
        workorderid = bound
        dbox.append(f'---{workorderid}---')
        #--------------------------------------
        
        try:
            proj = processing.run("native:extractbyexpression", {'INPUT':proj_lyr, 'EXPRESSION':f'"workorderid" = \'{workorderid}\'', 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            permits = processing.run("native:extractbylocation", {'INPUT':permit_lyr,'PREDICATE':[0],'INTERSECT':proj,'METHOD':0, 'OUTPUT': 'TEMPORARY_OUTPUT'})['OUTPUT']
            permit_ids = ', '.join([f"'{p['permit_name']}'" for p in permits.getFeatures()])
            #dbox.append(permit_ids)
            path_clip = processing.run("native:clip", {'INPUT':path_lyr,'OVERLAY':permits,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            path_permit = processing.run("native:extractbyexpression", {'INPUT': path_clip,'EXPRESSION':f'"permit_id" in ({permit_ids})','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            path_dissolved = processing.run("native:dissolve", {'INPUT':path_permit,'FIELD':["placement", "permit_id"],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            
            distance_calculator = QgsDistanceArea()
            distance_calculator.setEllipsoid(QgsProject.instance().ellipsoid())
            distance_calculator.setSourceCrs(QgsProject.instance().crs(), QgsProject.instance().transformContext())
            #distance_calculator.setEllipsoidalMode(True)

            dict = {}
            for f in path_dissolved.getFeatures():
                p = f['permit_id']
                if p not in dict:
                    dict[p] = [0,0,0] #, AE, UG, UNK
                geom = f.geometry()
                length_meters = distance_calculator.measureLength(geom)
                length_feet = length_meters * 3.28084
                
                if f['placement'] == 'PLACEMENT_AERIAL':
                    dict[p][0] += length_feet
                elif f['placement'] == 'PLACEMENT_UNDERGROUND':
                    dict[p][1] += length_feet
                else:
                    dict[p][2] += length_feet
            for p in dict:
                dbox.append(f'*-Permit {p} Footage-* \n\
                            Aerial Path Footage: {dict[p][0]:,.2f} ft\n\
                            Underground Path Footage: {dict[p][1]:,.2f} ft\n\
                            Undesignated Path Footage: {dict[p][2]:,.2f} ft \n\
                            Combined Dissolved Footage (AE+UG): {dict[p][0] + dict[p][1]:,.2f} ft')
             
            
        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            line_number = exc_traceback.tb_lineno
            dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))  
    

                 

