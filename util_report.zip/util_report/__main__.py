# -*- coding: utf-8 -*-
"""
Created on Friday, March 2025
Katapult Importer
@author: Marie Payne

Description:
- After exporting 'AGOL Data' & 'Node' reports from Katapult as excel from zip
- Join to the Pole layer in the Vero project using 'UID' fields
- copy over the data to the 'real' fields
- unjoin
"""
import os
from openpyxl import load_workbook
from datetime import datetime
import pandas as pd
import numpy as np
from zipfile import ZipFile
import sys
import time
from qgis.core import *
from qgis.PyQt.QtCore import QVariant
from qgis import processing
from datetime import datetime


def __main__(proj_area,outputfolder, dbox, progressBar,errorFormat, warningFormat, validFormat, checkbox):
    try:
        if proj_area in (None, '', 'NULL'):
            dbox.append(errorFormat.format(f'Select an a Project Workorderid to continue...'))
            return
        if outputfolder in (None, ''):
            dbox.append(errorFormat.format(f'Select an Output Folder location to continue...'))
            return
        dbox.append(f'Output: {outputfolder}')
        progressBar.setValue(5)
        project = QgsProject.instance()
        here = os.path.dirname(os.path.abspath(__file__))
        template = os.path.join(here, 'Utilization_Report_Template_v3.xlsx')
        wb = load_workbook(template)
        now = datetime.now()
        #layers
        fibercable = project.mapLayersByName('fibercable')[0]
        splice = project.mapLayersByName('spliceclosure')[0]
        address = project.mapLayersByName('address')[0]
        proj_lyr = project.mapLayersByName('project')[0]
        demarc = project.mapLayersByName('demarcarea')[0]
        structure = project.mapLayersByName('structure')[0]
        path = project.mapLayersByName('path')[0]
        slackloop = project.mapLayersByName('slackloop')[0]
        workorderid = proj_area['workorderid']
        progressBar.setValue(10)
        #AOI identified through workorderid on project layer. Each layer has a workorderid field.
        def validate_no_overlaps(layer, layer_name):
            dbox.append('Checking Path Features for Overlaps...')
            try:
                processing.run("qgis:selectbyexpression", {'INPUT':proj_lyr,'EXPRESSION':f'workorderid = \'{workorderid}\'','METHOD':0})['OUTPUT']
                processing.run("native:selectbylocation", {'INPUT':layer,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(proj_lyr.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':0})
                features = layer.getSelectedFeatures()
                total = layer.selectedFeatureCount()
                index = QgsSpatialIndex(features)
                id_to_uuid = {f.id(): f["globalid"] for f in layer.getSelectedFeatures()}
                uuid_to_feature = {f["globalid"]: f for f in layer.getSelectedFeatures()}
                id_to_geom = {f.id(): f.geometry() for f in layer.getSelectedFeatures()}

                errors = False
                dbox.append(f'Total Path Features: {str(total)}')
                for idx, feature in enumerate(layer.getSelectedFeatures(), 1):
                    geom = feature.geometry()
                    uuid = feature["globalid"]
                    if not geom or geom.isEmpty():# or geom.type() != QgsWkbTypes.PolygonGeometry:
                        dbox.append(f"[SKIP] {layer_name} Feature {uuid} has invalid geometry.")
                        continue
                    # Check single-part
                    if geom.isMultipart():
                        parts = geom.asGeometryCollection()
                        if len(parts) > 1:
                            dbox.append(f"[ERROR] {layer_name} Feature {uuid} is multipart.")
                            continue
                    else:
                        geom = geom.asGeometryCollection()[0]
                    # Check for interior overlaps
                    if layer.name() == 'Cabinet_Boundary':
                        if any(x in feature['fda_name'] for x in ['F0', 'F1']):
                            continue #skip if not F2. F1 and F0 can overlap.

                    bbox = geom.boundingBox()
                    candidate_ids = index.intersects(bbox)
                    
                    for cid in candidate_ids:
                        if cid == feature.id():
                            continue  # Skip self

                        other_geom = id_to_geom[cid]
                    
                        if not other_geom or other_geom.isEmpty():
                            dbox.append('not other geom')
                            continue

                        if layer.name() != 'Permits':
                            # Disallow any intersection that isn't just touching
                            if (geom.intersects(other_geom) and not geom.touches(other_geom)) or geom.equals(other_geom):
                                dbox.append(f"[ERROR] {layer_name} Feature {uuid} overlaps with Feature {id_to_uuid[cid]}")
                                errors = True
                        else:
                            #Permits may overlap, but cannot be the same geometry
                            if geom.equals(other_geom):
                                dbox.append(f"[ERROR] {layer_name} Feature {uuid} geometry is same as Feature {id_to_uuid[cid]}")
                                errors = True
                if errors:
                    dbox.append(errorFormat.format("Fix Path Features before continuing!"))
                return errors
            except Exception as e:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                line_number = exc_traceback.tb_lineno
                dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))
                errors = True
                return errors
    
        def QC():       
            #filter to workorderid
            #fibercable without capacity
            qc_errors = False
            q = processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and "cablecapacity" is Null','METHOD':0})['OUTPUT']
            dbox.append(f'{q.selectedFeatureCount()} Fibercable with NULL "cablecapacity".')
            if q.selectedFeatureCount() > 0:
                qc_errors = True
            #slackloop without associated fibercable name or capacity
            q = processing.run("qgis:selectbyexpression", {'INPUT':splice,'EXPRESSION':f'workorderid = \'{workorderid}\' and "hierarchy" is Null','METHOD':0})['OUTPUT']
            null_hier = q.selectedFeatureCount()
            dbox.append(f'{q.selectedFeatureCount()} Spliceclsoures with NULL "hierarchy".')
            if q.selectedFeatureCount() > 0:
                qc_errors = True
            '''#splice without type
            q = processing.run("qgis:selectbyexpression", {'INPUT':splice,'EXPRESSION':f'workorderid = \'{workorderid}\' and "type" is Null','METHOD':0})['OUTPUT']
            dbox.append(f'{q.selectedFeatureCount()} Spliceclsoures with NULL "type".')'''
            #spliceid does not have two dashes
            q = processing.run("qgis:selectbyexpression", {'INPUT':splice,'EXPRESSION':f'workorderid = \'{workorderid}\' and "spliceid" is Null','METHOD':0})['OUTPUT']
            dbox.append(f'{q.selectedFeatureCount()} Spliceclsoures with NULL "spliceid".')
            if q.selectedFeatureCount() > 0:
                qc_errors = True
            null_spliceid = q.selectedFeatureCount()
            if any(x>0 for x in [null_hier, null_spliceid]):
                raise Exception('Error. Fix NULL Spliceclosure "hierarchy" or "spliceid" values to continue with QC.137')

            q = processing.run("qgis:selectbyexpression", {'INPUT':splice,'EXPRESSION':f'workorderid = \'{workorderid}\'','METHOD':0})['OUTPUT']
            c = 0
            for f in q.selectedFeatures():
                if f['hierarchy'] == 'TIER2' and f['spliceid'].count('-') != 2:
                    c += 1
                elif f['hierarchy'] == 'AF' and f['spliceid'].count('-') != 3:
                    c += 1
                    #Tier 2 will have 2, AF will have 3, others will not have any dashes
            dbox.append(f'{c} Spliceclsoures with invalid "spliceid", missing or too many dashes.')
            if c > 0:
                qc_errors = True
            #structure without size
            q = processing.run("qgis:selectbyexpression", {'INPUT':structure,'EXPRESSION':f'workorderid = \'{workorderid}\' and "vaultsize" is Null','METHOD':0})['OUTPUT']
            dbox.append(f'{q.selectedFeatureCount()} Structures with NULL "size".')
            if q.selectedFeatureCount() > 0:
                qc_errors = True
            #path without installtype
            q = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and "installmethod" is NULL','METHOD':0})['OUTPUT']
            dbox.append(f'{q.selectedFeatureCount()} Path with NULL "installmethod".')
            if q.selectedFeatureCount() > 0:
                qc_errors = True
            #path hardscape without p6id in 8,10,12" listed
            q = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and ("installmethod" is \'ShallowTrenchHardscape\' and ("p6id" NOT ILIKE  \'%8\"%\' and "p6id" NOT ILIKE \'%10\"%\' and "p6id" NOT  ILIKE \'%12\"%\'))','METHOD':0})['OUTPUT']
            dbox.append(f'{q.selectedFeatureCount()} Hardscape Path with invalid "p6id" value.')
            if q.selectedFeatureCount() > 0:
                qc_errors = True
            progressBar.setValue(25)
            return qc_errors
            
        def util_report():
            ws = wb["New Utilization Report-Template"]
            dbox.append('Creating Utilization Report...')
            

            # RN2 = SPLICE ID [filter:'Tier2" hierarchy]
            RN2 = processing.run("qgis:selectbyexpression", {'INPUT':splice,'EXPRESSION':f'workorderid = \'{workorderid}\' and "hierarchy" = \'TIER2\'','METHOD':0})['OUTPUT']
            dbox.append(f'RN2 Count = {RN2.selectedFeatureCount()}')
            
            progressBar.setValue(30)
            r = 13 # defautl starting row in the template
            f1 = None
            f2 = None
            f1_count, f2_count = 1, 1
            progressBar.setValue(30)
            try:
                for f in list(sorted(RN2.selectedFeatures(), key=lambda f: f['spliceid'])):
                    #skip col 7 = G
                    ws.cell(r, 1).value = f['spliceid'].split('-')[0]
                    if f1 is not None and f['spliceid'].split('-')[0] != f1:
                        f1_count = 1
                        f1 = f['spliceid'].split('-')[0] 
                    ws.cell(r, 2).value = f1_count
                    ws.cell(r, 3).value = proj_area['segment_name']
                    ws.cell(r, 4).value = '-'.join(f['spliceid'].split('-')[:2])[:-1]
                    ws.cell(r,5).value = '-'.join(f['spliceid'].split('-')[:2])
                    if f2 is not None and '-'.join(f['spliceid'].split('-')[:2]) != f2:
                        f2_count = 1
                        f2 = '-'.join(f['spliceid'].split('-')[:2])
                    ws.cell(r, 6).value = f1_count
                    ws.cell(r, 8).value = f['spliceid']
                    r += 1
                    f1_count += 1
                    f2_count += 1
            except Exception as e:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                line_number = exc_traceback.tb_lineno
                dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))
            progressBar.setValue(30)
            # Filter Possible Addresses to those within the boundary
            bound = processing.run("qgis:selectbyexpression", {'INPUT':proj_lyr,'EXPRESSION':f'workorderid = \'{workorderid}\'','METHOD':0})['OUTPUT']
            progressBar.setValue(45)
            addrs = processing.run("native:selectbylocation", {'INPUT':address,'PREDICATE':[0],'INTERSECT':bound,'METHOD':0})['OUTPUT']
            progressBar.setValue(50)
            # Find closest address to RN2 location
            nearest_address = processing.run("native:joinbynearest", {'INPUT':QgsProcessingFeatureSourceDefinition(RN2.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'INPUT_2':addrs,'FIELDS_TO_COPY':[],'DISCARD_NONMATCHING':True,'PREFIX':'a_','NEIGHBORS':1,'MAX_DISTANCE':None,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            r = 13 # defautl starting row in the template
            try:
                for f in list(sorted(nearest_address.getFeatures(), key=lambda f: f['spliceid'])):
                    #skip col 9 = G
                    ws.cell(r, 10).value = f['a_pds_streetaddress'] if f['a_pds_streetaddress'] is not None else 'None'
                    ws.cell(r, 11).value = '1x64'
                    ws.cell(r, 12).value = 'ACTIVE' if f['status'] == 'FDA' else 'FUTURE' if f['status'] in ['PL', 'Planned'] else 'ERROR'
                    ws.cell(r, 14).value = 'YES' if ws.cell(r, 12).value == 'FUTURE' else None
                    r += 1
            except Exception as e:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                line_number = exc_traceback.tb_lineno
                dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))
                return
            progressBar.setValue(55)

            #address count within associated demarc boundary [filter:FDEC OR planned]
            demarcs = processing.run("native:joinattributesbylocation", {'INPUT':nearest_address,'PREDICATE':[0],'JOIN':demarc,'JOIN_FIELDS':[],'METHOD':0,'DISCARD_NONMATCHING':False,'PREFIX':'d_','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            #addrs_filter = processing.run("qgis:selectbyexpression", {'INPUT':address,'EXPRESSION':'status in (\'FDEC\', \'Planned\', \'PL\')','METHOD':0})['OUTPUT']
            addrs_filter = processing.run("native:extractbyexpression", {'INPUT':address,'EXPRESSION':'"status" in (\'FDEC\', \'Planned\', \'PL\')','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            progressBar.setValue(60)
            r = 13
            for d in set(list(sorted(demarcs.getFeatures(), key=lambda f: f['spliceid']))):
                globalid = d['d_globalid']
                demarc_a = processing.run("qgis:selectbyexpression", {'INPUT':demarc,'EXPRESSION':f'globalid= \'{globalid}\'','METHOD':0})['OUTPUT']
                for f in demarc_a.selectedFeatures():
                    dbox.append(f['name'])
                selection = processing.run("native:selectbylocation", {'INPUT':addrs_filter,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(demarc_a.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':2})['OUTPUT']
                count = selection.selectedFeatureCount()
                dbox.append(str(count))
                ws.cell(r, 13).value = count
                r += 1
            progressBar.setValue(75)

            #F3 Cable
            F3 = processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and "category" = \'AF\'','METHOD':0})['OUTPUT']
            progressBar.setValue(80)
            #F3 assigned fiber count, get only from features directly intersectin the RN2 splices. Downstream segments will have a lower value
            f3_selections = processing.run("native:selectbylocation", {'INPUT':F3,'PREDICATE':[0],'INTERSECT':QgsProcessingFeatureSourceDefinition(RN2.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':2})['OUTPUT']
            dbox.append(f'F3 Count = {f3_selections.selectedFeatureCount()}')
            progressBar.setValue(85)
            r = 13 # defautl sarting row in the template
            for f in list(sorted(f3_selections.selectedFeatures(), key=lambda f: f['cablename'])):
                ws.cell(r, 20).value = f['cablename'] if f['cablename'] not in [None, np.nan] else 'None'
                ws.cell(r, 22).value = f['assignedfibers'].split('-')[-1] if f['assignedfibers'] not in [None, np.nan] and '-' in f['assignedfibers'] else f['assignedfibers'] if f['assignedfibers'] not in [None, np.nan] and '-' not in f['assignedfibers'] else 'None'
                r += 1
            progressBar.setValue(90)
            wb.save(f'{outputfolder}\\UtilizationReport_{workorderid}_{now.strftime("%m_%d_%Y")}.xlsx')
            dbox.append(validFormat.format('Success. Created Utilization Report.'))

        def prelim_bom():
            ws2 = wb["Prelim BOM"]
            dbox.append('Creating Prelim BOM Sheet...')
            progressBar.setValue(0)
            # path - AF or below is 8", Tier2 and above is 12"
            total_footage = 0
            hsd8 = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'ShallowTrenchHardscape\' and p6id ILIKE \'%8\"%\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            hsd8_val = hsd8.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= hsd8.selectedFeatureIds())[0]
            ws2.cell(6, 1).value = hsd8_val

            hsd10 = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'ShallowTrenchHardscape\' and p6id ILIKE \'%10\"%\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            hsd10_val = hsd10.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= hsd10.selectedFeatureIds())[0]
            ws2.cell(6, 2).value = hsd10_val
            hsd12 = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'ShallowTrenchHardscape\' and p6id ILIKE \'%12\"%\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            hsd12_val = hsd12.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= hsd12.selectedFeatureIds())[0]
            ws2.cell(6, 3).value = hsd12_val
            db = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'DirectBury\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            db_val = db.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= db.selectedFeatureIds())[0]
            ws2.cell(6, 4).value = db_val
            ae = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'Aerial\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            ae_val = ae.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= ae.selectedFeatureIds())[0]
            ws2.cell(6, 5).value = ae_val
            bore = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'Bore\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            bore_val = bore.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= bore.selectedFeatureIds())[0]
            ws2.cell(6, 6).value = bore_val
            ot = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'TRENCH\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            ot_val = ot.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= ot.selectedFeatureIds())[0]
            ws2.cell(6, 7).value = ot_val
            ssd = processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and installmethod =  \'ShallowTrenchSoftscape\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            ssd_val = ssd.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= ssd.selectedFeatureIds())[0]
            ws2.cell(6, 8).value = ssd_val
            #processing.run("native:aggregate", {'INPUT':hsd8.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'GROUP_BY':'NULL','AGGREGATES':[{'aggregate': 'sum','delimiter': ',','input': '"calculatedlength"','length': 0,'name': 'new_field','precision': 0,'sub_type': 0,'type': 0,'type_name': ''}],'OUTPUT':'TEMPORARY_OUTPUT'})
            ws2.cell(2,1).value = hsd8_val + hsd10_val + hsd12_val + db_val + ae_val + bore_val + ot_val + ssd_val
            progressBar.setValue(30)
            # Structures
            xsv = processing.run("qgis:selectbyexpression", {'INPUT':structure,'EXPRESSION':f'workorderid = \'{workorderid}\' and vaultsize = \'XSV\'  and status = \'FDA\'','METHOD':0})['OUTPUT']
            ws2.cell(9, 1).value = xsv.selectedFeatureCount()
            dv = processing.run("qgis:selectbyexpression", {'INPUT':structure,'EXPRESSION':f'workorderid = \'{workorderid}\' and vaultsize = \'DV\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            ws2.cell(9, 2).value = dv.selectedFeatureCount()
            sv = processing.run("qgis:selectbyexpression", {'INPUT':structure,'EXPRESSION':f'workorderid = \'{workorderid}\' and vaultsize = \'SV\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            ws2.cell(9, 3).value = sv.selectedFeatureCount()
            lv = processing.run("qgis:selectbyexpression", {'INPUT':structure,'EXPRESSION':f'workorderid = \'{workorderid}\' and vaultsize = \'LV\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            ws2.cell(9, 4).value = lv.selectedFeatureCount()
            xlv = processing.run("qgis:selectbyexpression", {'INPUT':structure,'EXPRESSION':f'workorderid = \'{workorderid}\' and vaultsize = \'XLV\' and status = \'FDA\'','METHOD':0})['OUTPUT']
            progressBar.setValue(40)
            ws2.cell(9, 5).value = xlv.selectedFeatureCount()
            progressBar.setValue(50)

            #FiberCable - with slackloop footages assocated by cablename
            fc24 = processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and cablecapacity = 24  and status = \'FDA\'','METHOD':0})['OUTPUT']
            sl24 = processing.run("qgis:selectbyexpression", {'INPUT':slackloop,'EXPRESSION':f'workorderid = \'{workorderid}\' and cablecapacity = 24  and status = \'FDA\'','METHOD':0})['OUTPUT']
            ws2.cell(12, 1).value = fc24.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= fc24.selectedFeatureIds())[0] + sl24.aggregate(QgsAggregateCalculator.Sum, "measuredlength", fids= sl24.selectedFeatureIds())[0]
            progressBar.setValue(60)

            fc96 = processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and cablecapacity = 96  and status = \'FDA\'','METHOD':0})['OUTPUT']
            sl96 = processing.run("qgis:selectbyexpression", {'INPUT':slackloop,'EXPRESSION':f'workorderid = \'{workorderid}\' and cablecapacity = 96  and status = \'FDA\'','METHOD':0})['OUTPUT']
            ws2.cell(12, 2).value = fc96.aggregate(QgsAggregateCalculator.Sum, "calculatedlength",fids= fc96.selectedFeatureIds())[0] + sl96.aggregate(QgsAggregateCalculator.Sum, "measuredlength",fids= sl96.selectedFeatureIds())[0]
            progressBar.setValue(70)
            
            fc432 = processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and cablecapacity = 432  and status = \'FDA\'','METHOD':0})['OUTPUT']
            sl432 = processing.run("qgis:selectbyexpression", {'INPUT':slackloop,'EXPRESSION':f'workorderid = \'{workorderid}\' and cablecapacity = 432  and status = \'FDA\'','METHOD':0})['OUTPUT']
            ws2.cell(12, 3).value = fc432.aggregate(QgsAggregateCalculator.Sum, "calculatedlength",fids= fc432.selectedFeatureIds())[0] + sl432.aggregate(QgsAggregateCalculator.Sum, "measuredlength",fids= sl432.selectedFeatureIds())[0]
            progressBar.setValue(80)
            
            try:
                #(Row 21) F0-2 Billing Footage: Sum of dissolved footage of F0-2 Fibercable within project boundary: Dissolve fibercable whose category is equal to DF, BB, and TIER2. Clip to project boundary. Sum re-calculated lengths.
                FC_F02 = processing.run("native:extractbyexpression", {'INPUT':fibercable ,'EXPRESSION':f'"workorderid" = \'{workorderid}\' and "category" in (\'DF\', \'BB\',\'TIER2\')','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                FC_F02_clip = processing.run("native:clip", {'INPUT':FC_F02,'OVERLAY':QgsProcessingFeatureSourceDefinition(proj_lyr.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                FC_F02_dissolved = processing.run("native:dissolve", {'INPUT':FC_F02_clip,'FIELD':[],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
               
                distance_calculator = QgsDistanceArea()
                distance_calculator.setEllipsoid(QgsProject.instance().ellipsoid())
                distance_calculator.setSourceCrs(QgsProject.instance().crs(), QgsProject.instance().transformContext())
                #distance_calculator.setEllipsoidalMode(True)

                FC_F02_sum_length_feet = 0
                for f in FC_F02_dissolved.getFeatures():
                    geom = f.geometry()
                    length_meters = distance_calculator.measureLength(geom)
                    length_feet = length_meters * 3.28084
                    FC_F02_sum_length_feet += length_feet
                ws2.cell(21, 2).value = FC_F02_sum_length_feet
                #(Row 22) Total Project Footage: Sum of calculated footage of path layer that matches the project's workorderid (do not take into account path status)
                '''processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\'','METHOD':0})['OUTPUT']
                path_footage = path.aggregate(QgsAggregateCalculator.Sum, "calculatedlength", fids= path.selectedFeatureIds())[0]

                processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and category not in (\'DROP\')','METHOD':0})['OUTPUT']
                processing.run("qgis:selectbyexpression", {'INPUT':path,'EXPRESSION':f'workorderid = \'{workorderid}\' and hierarchy in (\'AF\', \'BB\', \'DF\')','METHOD':0})['OUTPUT']
                processing.run("native:selectbylocation", {'INPUT':fibercable,'PREDICATE':[5],'INTERSECT':QgsProcessingFeatureSourceDefinition(path.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'METHOD':2})
                FC_trim_dissolved = processing.run("native:dissolve", {'INPUT':QgsProcessingFeatureSourceDefinition(fibercable.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'FIELD':[],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                FC_trim_sum_length_feet = 0
                for f in FC_trim_dissolved.getFeatures():
                    geom = f.geometry()
                    length_meters = distance_calculator.measureLength(geom)
                    length_feet = length_meters * 3.28084
                    FC_trim_sum_length_feet += length_feet
                ws2.cell(22, 2).value = path_footage + FC_trim_sum_length_feet
                ws2.cell(23,2).value = f'{str(path_footage)} + {str(FC_trim_sum_length_feet)} ' '''
                FC = processing.run("native:extractbyexpression", {'INPUT':fibercable ,'EXPRESSION':f'"workorderid" = \'{workorderid}\' and "category" not in (\'DROP\')','OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                FC_dissolved = processing.run("native:dissolve", {'INPUT':FC,'FIELD':[],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
                FC_sum_length_feet = 0
                for f in FC_dissolved.getFeatures():
                    geom = f.geometry()
                    length_meters = distance_calculator.measureLength(geom)
                    length_feet = length_meters * 3.28084
                    FC_sum_length_feet += length_feet
                ws2.cell(22,2).value = FC_sum_length_feet
            except Exception as e:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                line_number = exc_traceback.tb_lineno
                dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))

            progressBar.setValue(60)

            '''#proposed infrastructure footage, linear
            allfootage =  processing.run("qgis:selectbyexpression", {'INPUT':fibercable,'EXPRESSION':f'workorderid = \'{workorderid}\' and cablecapacity in (24, 96, 432)','METHOD':0})['OUTPUT']
            dissolved = processing.run("native:dissolve", {'INPUT':QgsProcessingFeatureSourceDefinition(allfootage.id(), selectedFeaturesOnly=True, featureLimit=-1, geometryCheck=QgsFeatureRequest.GeometryAbortOnInvalid),'FIELD':[],'SEPARATE_DISJOINT':False,'OUTPUT':'TEMPORARY_OUTPUT'})['OUTPUT']
            progressBar.setValue(90)
            dissolved_footage = 0
            project.addMapLayer(dissolved)
            distance_calculator = QgsDistanceArea()
            distance_calculator.setEllipsoid(dissolved.crs().ellipsoid())
            for feature in dissolved.getFeatures():
                geo = feature.geometry()
                dissolved_footage += geo.length()
                print(dissolved_footage)
            ws2.cell(2, 1).value = dissolved_footage'''
            progressBar.setValue(95)
            #
            wb.save(f'{outputfolder}\\UtilizationReport_{workorderid}_{now.strftime("%m_%d_%Y")}.xlsx')
            dbox.append(validFormat.format('Success. Added Prelim BOM to Utilization Report.'))
        def change_log():
            progressBar.setValue(99)
            pass
        
        errors = validate_no_overlaps(path, "path")
        dbox.append(str(errors))
        if not errors:
            qc_errors = QC()
            if not qc_errors:
                if checkbox.isChecked() == False:
                    util_report()
                prelim_bom()
                change_log() 
            progressBar.setValue(100)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        line_number = exc_traceback.tb_lineno
        dbox.append(errorFormat.format(f'{e}, {exc_type}, {exc_value}, {line_number}'))